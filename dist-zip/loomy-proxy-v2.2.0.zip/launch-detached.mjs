#!/usr/bin/env node
// launch-detached.mjs —— 把 node 脚本放进「完全脱离当前控制台」的进程里后台运行。
//
// 为什么需要它（2026-10-20 实测踩坑）：
//   用 `start "标题" node xxx.mjs` 或 Start-Process 起的进程仍然挂在启动它的那个终端
//   窗口上。Windows Terminal 关窗口会向该窗口里的所有控制台进程发 CTRL_CLOSE，用户一
//   关窗口，后台服务就被一起杀掉；而且 stdout 只留在那个窗口里，事后完全查不到日志
//   （logs/proxy.log 里一条新记录都没有，等于没有任何现场）。
//
// 做法：spawn 时带 detached: true（Windows 上相当于 DETACHED_PROCESS，子进程不挂控制台），
// stdio 直接落到日志文件，父进程立刻退出并打印子进程 pid。这样：
//   1. 关掉启动它的窗口不影响服务；
//   2. 日志永远在文件里，事后可查；
//   3. 不依赖 wscript / PowerShell，只需要 node 本身。
//
// 用法：
//   node launch-detached.mjs <out.log> <err.log> <script.mjs> [脚本参数...]
// 输出：成功时打印 `pid=<子进程 pid>`；参数不足退出码 2；启动失败退出码 1。

import { spawn } from 'node:child_process'
import { existsSync, mkdirSync, openSync, closeSync } from 'node:fs'
import { dirname } from 'node:path'

const argv = process.argv.slice(2)
if (argv.length < 3) {
  console.error('用法: node launch-detached.mjs <out.log> <err.log> <script.mjs> [脚本参数...]')
  process.exit(2)
}

const [outLog, errLog, script, ...scriptArgs] = argv

if (!existsSync(script)) {
  console.error(`脚本不存在: ${script}`)
  process.exit(2)
}

for (const p of [outLog, errLog]) {
  const dir = dirname(p)
  if (dir) {
    try {
      mkdirSync(dir, { recursive: true })
    } catch (err) {
      console.error(`创建日志目录失败 ${dir}: ${err.message}`)
      process.exit(1)
    }
  }
}

let outFd
let errFd
try {
  outFd = openSync(outLog, 'a')
  errFd = openSync(errLog, 'a')
} catch (err) {
  console.error(`打不开日志文件: ${err.message}`)
  process.exit(1)
}

let child
try {
  child = spawn(process.execPath, [script, ...scriptArgs], {
    detached: true,
    windowsHide: true,
    stdio: ['ignore', outFd, errFd],
  })
} catch (err) {
  console.error(`启动失败: ${err.message}`)
  process.exit(1)
} finally {
  closeSync(outFd)
  closeSync(errFd)
}

child.on('error', (err) => {
  console.error(`启动失败: ${err.message}`)
  process.exitCode = 1
})

child.unref()

if (child.pid) console.log(`pid=${child.pid}`)
