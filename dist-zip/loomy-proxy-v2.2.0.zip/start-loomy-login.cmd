@echo off
rem Start Loomy web-login auth service (no desktop client needed)
rem Opens http://127.0.0.1:8791 ; login with phone + SMS code -> writes web-session.json
rem Runs DETACHED and hidden; closing this window does NOT stop it.
rem Logs: logs\web-auth.log  /  logs\web-auth.err.log   Stop: stop-all.cmd
setlocal
set "PORT=8791"
set "ROOT=%~dp0"
set "NODE=%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe"
if not exist "%NODE%" set "NODE=node"
curl.exe -s -m 2 "http://127.0.0.1:%PORT%/health" >nul 2>&1
if not errorlevel 1 (
  echo [loomy-web-auth] already running, opening browser...
  start "" "http://127.0.0.1:%PORT%"
  exit /b 0
)
cd /d "%ROOT%"
if not exist "%ROOT%logs" mkdir "%ROOT%logs"
"%NODE%" "%ROOT%launch-detached.mjs" "%ROOT%logs\web-auth.log" "%ROOT%logs\web-auth.err.log" "%ROOT%web-auth.mjs" --port=%PORT%
ping -n 3 127.0.0.1 >nul
start "" "http://127.0.0.1:%PORT%"
echo [loomy-web-auth] started in background: http://127.0.0.1:%PORT%   (log = logs\web-auth.log)
