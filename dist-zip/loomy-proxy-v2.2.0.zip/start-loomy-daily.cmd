@echo off
rem Loomy 每日任务 / 签到（默认只读检查，加 --apply 才领取）
rem   start-loomy-daily.cmd            只读检查：新手任务完成度 + 今日打工奖励 + 余额
rem   start-loomy-daily.cmd --apply    领取可合法领取的奖励（新手任务 / 首次登录 / 已达成档位的打工奖励）
rem 打工奖励只在本地能找到客户端真实活动记录时才领取，找不到就跳过（不伪造活动数据）。
setlocal
set "NODE=%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe"
if not exist "%NODE%" set "NODE=node"
cd /d "%~dp0"
"%NODE%" "%~dp0daily-tasks.mjs" %*
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" echo [daily-tasks] 退出码 %RC%（有账号检查失败，见上面的错误行）
if "%~1"=="" pause
exit /b %RC%
