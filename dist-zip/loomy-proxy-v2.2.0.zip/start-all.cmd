@echo off
rem =====================================================================
rem  Start the whole Loomy stack with one double-click:
rem    [1/2] reverse proxy   -> http://127.0.0.1:8790  (required)
rem    [2/2] web-login svc  -> http://127.0.0.1:8791  (only for adding /
rem          switching accounts; safe to leave running)
rem
rem  Both services are launched DETACHED and hidden (via launch-detached.mjs),
rem  so closing this window does NOT stop them. Their output always goes to
rem  logs\proxy.log / logs\web-auth.log, so you can inspect it later.
rem  To stop them: run stop-all.cmd
rem
rem  Idempotent: anything already running is detected via /health and
rem  skipped, so double-clicking twice never spawns duplicates.
rem  Usage:  start-all.cmd            (keeps window open, shows health)
rem          start-all.cmd --no-pause (headless / scripted use)
rem =====================================================================
setlocal
set "ROOT=%~dp0"
set "PORT_PROXY=8790"
set "PORT_LOGIN=8791"
set "LOGS=%ROOT%logs"

rem Node: prefer the DSH bundled runtime, fall back to PATH.
set "NODE=%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe"
if not exist "%NODE%" set "NODE=node"
set "LAUNCH=%ROOT%launch-detached.mjs"

cd /d "%ROOT%"
if not exist "%LOGS%" mkdir "%LOGS%"

echo === Loomy stack ===

rem ---------- [1/2] reverse proxy ----------
curl.exe -s -m 2 "http://127.0.0.1:%PORT_PROXY%/health" >nul 2>&1
if not errorlevel 1 (
  echo [1/2] proxy    : already running   http://127.0.0.1:%PORT_PROXY%
) else (
  "%NODE%" "%LAUNCH%" "%LOGS%\proxy.log" "%LOGS%\proxy.err.log" "%ROOT%loomy-proxy.mjs" --port=%PORT_PROXY%
  echo [1/2] proxy    : started in background   http://127.0.0.1:%PORT_PROXY%
)

rem ---------- [2/2] web-login service ----------
curl.exe -s -m 2 "http://127.0.0.1:%PORT_LOGIN%/health" >nul 2>&1
if not errorlevel 1 (
  echo [2/2] web-auth : already running   http://127.0.0.1:%PORT_LOGIN%
) else (
  "%NODE%" "%LAUNCH%" "%LOGS%\web-auth.log" "%LOGS%\web-auth.err.log" "%ROOT%web-auth.mjs" --port=%PORT_LOGIN%
  echo [2/2] web-auth : started in background   http://127.0.0.1:%PORT_LOGIN%
)

rem give the processes a moment to bind their ports
rem (ping instead of timeout: timeout refuses to run when stdin is redirected)
ping -n 4 127.0.0.1 >nul

echo.
echo === health ===
echo proxy:
curl.exe -s -m 5 "http://127.0.0.1:%PORT_PROXY%/health"
echo.
echo web-auth:
curl.exe -s -m 5 "http://127.0.0.1:%PORT_LOGIN%/health"
echo.
echo.
echo proxy    : http://127.0.0.1:%PORT_PROXY%/health
echo admin    : http://127.0.0.1:%PORT_PROXY%/admin
echo web-login: http://127.0.0.1:%PORT_LOGIN%   (only needed to add / switch accounts)
echo logs     : logs\proxy.log  /  logs\web-auth.log
echo stop     : run stop-all.cmd  (closing this window will NOT stop them)
echo.
if /i not "%~1"=="--no-pause" pause
exit /b 0
