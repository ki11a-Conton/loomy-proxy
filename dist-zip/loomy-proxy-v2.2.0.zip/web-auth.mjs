#!/usr/bin/env node
/**
 * Loomy 网页登录授权服务（无需桌面客户端）
 *
 * 原理：Loomy 桌面端的登录 = 讯飞账号（account.xfinfr.com）手机号 + 短信验证码，
 * 返回的 session 就是网关 https://loomyad.xunfei.cn/api/v1 认可的鉴权 token。
 * 本服务复刻同一登录流程（签名算法与客户端一致），在本机网页上完成登录，
 * 把 session 写入 web-session.json，供 loomy-proxy.mjs 直接使用。
 *
 * 启动： node web-auth.mjs   （默认 http://127.0.0.1:8791）
 * 仅监听 127.0.0.1，token 不会离开本机（登录请求本身直连讯飞账号接口）。
 */
import http from 'node:http'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import {
  loadAccountConfig,
  sendSmsCode,
  loginBySmsCode,
  checkGateway,
  maskSession,
  GATEWAY_BASE,
} from './lib/xfyun-account.mjs'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const PORT = Number(process.env.PORT || process.argv.find(a => /^--port=/.test(a))?.split('=')[1] || 8791)
const HOST = process.env.HOST || '127.0.0.1'
const WEB_SESSION_FILE = path.join(__dirname, 'web-session.json')

const log = (...a) => console.log(new Date().toISOString(), ...a)

function readWebSession() {
  try {
    const j = JSON.parse(fs.readFileSync(WEB_SESSION_FILE, 'utf8'))
    return j && j.session ? j : null
  } catch { return null }
}

function writeWebSession(obj) {
  fs.writeFileSync(WEB_SESSION_FILE, JSON.stringify(obj, null, 2) + '\n', { encoding: 'utf8', mode: 0o600 })
}

/* ------------------------------- 登录页 HTML ------------------------------- */

const PAGE = `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Loomy 网页登录 · 拿 session token</title>
<style>
  :root { color-scheme: dark; --bg:#0b0d12; --card:#141821; --line:#242a38; --fg:#e6e9f0; --dim:#8b93a7; --acc:#6c8cff; --ok:#37c98b; --err:#ff6b6b; }
  * { box-sizing: border-box; }
  body { margin:0; min-height:100vh; display:flex; align-items:center; justify-content:center; padding:24px;
         background: radial-gradient(1200px 600px at 20% -10%, #1b2340 0%, transparent 60%), radial-gradient(900px 500px at 110% 110%, #152b2a 0%, transparent 55%), var(--bg);
         color:var(--fg); font: 15px/1.55 "Segoe UI", system-ui, -apple-system, "Microsoft YaHei", sans-serif; }
  .wrap { width: min(520px, 100%); }
  h1 { font-size: 22px; margin: 0 0 6px; letter-spacing: .3px; }
  .sub { color: var(--dim); font-size: 13px; margin: 0 0 20px; }
  .card { background: color-mix(in srgb, var(--card) 92%, transparent); border: 1px solid var(--line);
          border-radius: 16px; padding: 22px; box-shadow: 0 12px 40px rgba(0,0,0,.45); }
  label { display:block; font-size: 12px; color: var(--dim); margin: 0 0 6px; }
  .row { display:flex; gap:10px; }
  input { flex:1; width:100%; background:#0e1118; border:1px solid var(--line); color:var(--fg);
          border-radius:10px; padding:12px 14px; font-size:15px; outline:none; transition:border-color .15s; }
  input:focus { border-color: var(--acc); }
  button { border:0; border-radius:10px; padding:12px 16px; font-size:14px; font-weight:600; cursor:pointer;
           background: var(--acc); color:#fff; white-space:nowrap; transition: filter .15s; }
  button:hover { filter: brightness(1.08); }
  button:disabled { opacity:.55; cursor: not-allowed; filter:none; }
  button.ghost { background:#1b2130; color:var(--fg); border:1px solid var(--line); }
  .field { margin-bottom: 14px; }
  .mt { margin-top: 14px; }
  .msg { min-height: 20px; font-size: 13px; margin-top: 12px; }
  .msg.err { color: var(--err); } .msg.ok { color: var(--ok); }
  .token { margin-top: 18px; border-top: 1px dashed var(--line); padding-top: 16px; display:none; }
  .token.show { display:block; }
  .kv { display:grid; grid-template-columns: 92px 1fr; gap: 8px 12px; font-size: 13px; }
  .kv .k { color: var(--dim); }
  .kv .v { word-break: break-all; font-family: Consolas, monospace; }
  .pill { display:inline-block; padding:1px 8px; border-radius:999px; font-size:12px; border:1px solid var(--line); }
  .pill.ok { color: var(--ok); border-color: color-mix(in srgb, var(--ok) 45%, var(--line)); }
  .pill.err { color: var(--err); border-color: color-mix(in srgb, var(--err) 45%, var(--line)); }
  .actions { display:flex; gap:10px; margin-top:14px; flex-wrap:wrap; }
  .hint { color: var(--dim); font-size: 12px; margin-top: 10px; }
  code { background:#0e1118; border:1px solid var(--line); padding:1px 6px; border-radius:6px; font-family:Consolas,monospace; font-size:12.5px; }
  a { color: var(--acc); }
</style>
</head>
<body>
<div class="wrap">
  <h1>Loomy 网页登录</h1>
  <p class="sub">手机号 + 短信验证码登录讯飞账号，直接换取 Loomy 网关可用的 session token。<br>
  与桌面客户端同一套登录接口，无需安装/启动 Loomy。</p>

  <div class="card">
    <div class="field">
      <label>手机号</label>
      <div class="row">
        <input id="phone" inputmode="numeric" placeholder="11 位手机号" autocomplete="tel">
        <button id="btnSend">发送验证码</button>
      </div>
    </div>
    <div class="field">
      <label>短信验证码</label>
      <div class="row">
        <input id="code" inputmode="numeric" placeholder="6 位验证码" autocomplete="one-time-code" maxlength="6">
        <button id="btnLogin">登录并获取 token</button>
      </div>
    </div>
    <div id="msg" class="msg"></div>

    <div id="tokenBox" class="token">
      <div class="kv">
        <span class="k">session</span><span class="v" id="vSession"></span>
        <span class="k">账号</span><span class="v" id="vPhone"></span>
        <span class="k">userid</span><span class="v" id="vUserid"></span>
        <span class="k">网关校验</span><span class="v" id="vGateway"></span>
        <span class="k">保存于</span><span class="v" id="vFile">web-session.json</span>
      </div>
      <div class="actions">
        <button class="ghost" id="btnCopy">复制完整 token</button>
        <button class="ghost" id="btnCheck">重新校验网关</button>
        <button class="ghost" id="btnLogout">退出登录</button>
      </div>
      <div class="hint">反代 <code>loomy-proxy.mjs</code> 会自动读取最新 session；登录后无需改配置。</div>
    </div>
  </div>

  <p class="hint">网关：<code>${GATEWAY_BASE}</code> · 登录接口：讯飞账号 <code>account.xfinfr.com</code> · 仅本机 127.0.0.1</p>
</div>

<script>
const $ = (id) => document.getElementById(id)
let msgid = ''
let fullSession = ''

function setMsg(text, kind = '') {
  const el = $('msg')
  el.className = 'msg' + (kind ? ' ' + kind : '')
  el.textContent = text || ''
}
function busy(btn, on) { btn.disabled = on }

async function api(path, body) {
  const res = await fetch(path, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body || {}),
  })
  const json = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(json.error || ('HTTP ' + res.status))
  return json
}

function renderStatus(st) {
  const box = $('tokenBox')
  if (!st || !st.session) { box.classList.remove('show'); return }
  box.classList.add('show')
  fullSession = st.session || ''
  $('vSession').textContent = st.sessionMasked || ''
  $('vPhone').textContent = st.phone || '—'
  $('vUserid').textContent = st.userid || '—'
  const g = st.gateway || {}
  const el = $('vGateway')
  if (g.ok) {
    el.innerHTML = '<span class="pill ok">通过</span> 模型 ' + (g.modelCount || 0) + ' 个'
  } else {
    el.innerHTML = '<span class="pill err">未通过</span> ' + (g.desc || g.error || g.code || '')
  }
  $('vFile').textContent = st.file || 'web-session.json'
}

async function refreshStatus() {
  try {
    const res = await fetch('/api/status')
    const st = await res.json()
    renderStatus(st)
  } catch {}
}

$('btnSend').addEventListener('click', async () => {
  const phone = $('phone').value.trim()
  if (!/^1[3-9]\\d{9}$/.test(phone)) return setMsg('请输入正确的 11 位手机号', 'err')
  const btn = $('btnSend'); busy(btn, true)
  try {
    setMsg('正在发送短信…')
    const r = await api('/api/send', { phone })
    msgid = r.msgid
    setMsg('验证码已发送，请查收短信（5 分钟内有效）', 'ok')
    $('code').focus()
  } catch (e) { setMsg('发送失败：' + e.message, 'err') }
  finally { busy(btn, false) }
})

$('btnLogin').addEventListener('click', async () => {
  const phone = $('phone').value.trim()
  const code = $('code').value.trim()
  if (!/^1[3-9]\\d{9}$/.test(phone)) return setMsg('请先填写手机号', 'err')
  if (!/^\\d{4,8}$/.test(code)) return setMsg('请输入短信验证码', 'err')
  if (!msgid) return setMsg('请先点「发送验证码」', 'err')
  const btn = $('btnLogin'); busy(btn, true)
  try {
    setMsg('正在登录并校验网关…')
    const r = await api('/api/login', { phone, code, msgid })
    if (!r.ok) { setMsg('登录失败：' + (r.error || '未知错误'), 'err'); return }
    renderStatus(r.status)
    setMsg(r.gateway && r.gateway.ok ? '登录成功，token 已保存，反代可以直接使用 ✅' : '登录成功，但网关校验未通过（见下方）', r.gateway && r.gateway.ok ? 'ok' : 'err')
  } catch (e) { setMsg('登录失败：' + e.message, 'err') }
  finally { busy(btn, false) }
})

$('btnCopy').addEventListener('click', async () => {
  if (!fullSession) return
  try { await navigator.clipboard.writeText(fullSession); setMsg('完整 token 已复制到剪贴板', 'ok') }
  catch { setMsg('复制失败，请手动复制（见下方 session 字段）', 'err') }
})

$('btnCheck').addEventListener('click', async () => {
  try {
    setMsg('校验中…')
    const r = await api('/api/check', {})
    renderStatus(r.status)
    setMsg(r.gateway && r.gateway.ok ? '网关校验通过 ✅' : '网关校验未通过', r.gateway && r.gateway.ok ? 'ok' : 'err')
  } catch (e) { setMsg('校验失败：' + e.message, 'err') }
})

$('btnLogout').addEventListener('click', async () => {
  try {
    await api('/api/logout', {})
    fullSession = ''
    $('tokenBox').classList.remove('show')
    setMsg('已清除本机保存的 token（不影响桌面客户端授权）', 'ok')
  } catch (e) { setMsg('退出失败：' + e.message, 'err') }
})

refreshStatus()
</script>
</body>
</html>`

/* ------------------------------- HTTP 服务 ------------------------------- */

function send(res, status, obj, headers = {}) {
  const body = JSON.stringify(obj)
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'content-length': Buffer.byteLength(body), ...headers })
  res.end(body)
}

function readBody(req, limit = 64 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = []
    let size = 0
    req.on('data', c => {
      size += c.length
      if (size > limit) { reject(new Error('请求体过大')); req.destroy(); return }
      chunks.push(c)
    })
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')))
    req.on('error', reject)
  })
}

function statusSnapshot() {
  const st = readWebSession()
  if (!st) return null
  return {
    session: st.session,
    sessionMasked: maskSession(st.session),
    phone: st.phone || '',
    userid: st.userid || '',
    updatedAt: st.updatedAt || 0,
    gateway: st.gateway || null,
    file: path.basename(WEB_SESSION_FILE),
  }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || `${HOST}:${PORT}`}`)
  const p = url.pathname

  try {
    if (req.method === 'GET' && (p === '/' || p === '/login')) {
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' })
      res.end(PAGE)
      return
    }
    if (req.method === 'GET' && p === '/health') {
      return send(res, 200, { ok: true, service: 'loomy-web-auth', session: !!readWebSession() })
    }
    if (req.method === 'GET' && p === '/api/status') {
      return send(res, 200, statusSnapshot())
    }

    if (req.method === 'POST' && p === '/api/send') {
      const body = JSON.parse((await readBody(req)) || '{}')
      const phone = String(body.phone || '').trim()
      const r = await sendSmsCode(phone)
      if (!r.success) {
        log('sendMsgCode failed', r.code, r.error)
        return send(res, 200, { ok: false, error: r.error || '发送失败', code: r.code })
      }
      const msgid = r.data?.data?.msgid || r.data?.msgid || ''
      log('sendMsgCode ok', phone.slice(0, 3) + '****' + phone.slice(-4), 'msgid', String(msgid).slice(0, 8) + '…')
      return send(res, 200, { ok: true, msgid })
    }

    if (req.method === 'POST' && p === '/api/login') {
      const body = JSON.parse((await readBody(req)) || '{}')
      const phone = String(body.phone || '').trim()
      const code = String(body.code || '').trim()
      const msgid = String(body.msgid || '').trim()
      const r = await loginBySmsCode(phone, code, msgid)
      if (!r.success) {
        log('checkCode failed', r.code, r.error)
        return send(res, 200, { ok: false, error: r.error || '登录失败', code: r.code })
      }
      const d = r.data?.data || {}
      const session = d.session || r.data?.session || ''
      const userid = d.userid || r.data?.userid || ''
      if (!session) {
        log('login ok but no session field', Object.keys(r.data || {}))
        return send(res, 200, { ok: false, error: '登录成功但响应里没有 session 字段' })
      }
      const gateway = await checkGateway(session)
      const record = {
        kind: 'gateway-session', // 网关可用会话（反代只认这种；网页 cookie 会话不带此标记）
        session,
        phone,
        userid: String(userid),
        source: 'xfyun-sms-web',
        updatedAt: Date.now(),
        gateway: { ok: !!gateway.ok, code: gateway.code || '', desc: gateway.desc || gateway.error || '', modelCount: gateway.modelCount || 0 },
      }
      writeWebSession(record)
      log('login ok', 'userid', userid, 'gateway', gateway.ok ? 'OK' : 'FAIL')
      return send(res, 200, { ok: true, gateway, status: statusSnapshot() })
    }

    if (req.method === 'POST' && p === '/api/check') {
      const st = readWebSession()
      if (!st) return send(res, 200, { ok: false, error: '本机尚未保存 token', gateway: { ok: false, error: '无 session' }, status: null })
      const gateway = await checkGateway(st.session)
      st.gateway = { ok: !!gateway.ok, code: gateway.code || '', desc: gateway.desc || gateway.error || '', modelCount: gateway.modelCount || 0 }
      st.updatedAt = st.updatedAt || Date.now()
      writeWebSession(st)
      log('gateway check', gateway.ok ? 'OK' : 'FAIL')
      return send(res, 200, { ok: !!gateway.ok, gateway, status: statusSnapshot() })
    }

    if (req.method === 'POST' && p === '/api/logout') {
      try { fs.unlinkSync(WEB_SESSION_FILE) } catch {}
      log('web session cleared')
      return send(res, 200, { ok: true })
    }

    return send(res, 404, { error: 'Not Found' })
  } catch (err) {
    log('request error', p, String(err?.message || err))
    return send(res, 400, { error: String(err?.message || err) })
  }
})

try {
  const cfg = loadAccountConfig()
  log(`Loomy 网页登录服务已启动：http://${HOST}:${PORT}`)
  log(`凭据来源：${cfg.envPath}`)
  log('打开上面的地址，输入手机号 + 短信验证码即可换取 session token')
} catch (err) {
  log('启动失败：', err.message)
  process.exit(1)
}

server.listen(PORT, HOST, () => {
  log(`listening on http://${HOST}:${PORT}`)
})
