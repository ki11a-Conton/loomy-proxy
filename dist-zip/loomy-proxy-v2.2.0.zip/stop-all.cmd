@echo off
rem ---------------------------------------------------------------------
rem  Stop the Loomy stack (reverse proxy 8790 + web-login service 8791).
rem
rem  It only kills the processes LISTENING on 8790/8791, so other node.exe
rem  processes on this machine are never touched.
rem  Closing the start-all.cmd window does NOT stop the services -- use this.
rem  Usage: stop-all.cmd            (keeps window open)
rem         stop-all.cmd --no-pause (scripted use)
rem ---------------------------------------------------------------------
setlocal
echo === stop Loomy stack ===
call :killport 8790 proxy
call :killport 8791 web-auth
echo done.
if /i not "%~1"=="--no-pause" pause
exit /b 0

:killport
set "KPID="
for /f "tokens=5" %%a in ('netstat -ano ^| findstr /c:":%~1 " ^| findstr /c:"LISTENING"') do if not defined KPID set "KPID=%%a"
if not defined KPID (
  echo   port %~1 ^(%~2^): not listening, nothing to stop
  goto :eof
)
taskkill /f /pid %KPID% >nul 2>&1
if errorlevel 1 (
  echo   port %~1 ^(%~2^): could not stop pid=%KPID%
) else (
  echo   port %~1 ^(%~2^): stopped pid=%KPID%
)
goto :eof
