#!/usr/bin/env node
/**
 * Loomy 每日任务 / 签到（零依赖单文件）
 *
 * 默认是「只读检查」：把每个账号的
 *   ① 新手任务完成度   GET  /api/v1/onboarding/tasks
 *   ② 今日打工奖励     GET  /api/v1/pet-work
 *   ③ 积分余额/今日额度 GET  /api/v1/points/records
 *   ④ 激活状态         GET  /api/v1/points/activation
 * 拉下来汇总，并写入 daily-tasks-state.json 供反代面板展示。
 *
 * 加 --apply 才会做写操作：
 *   · 未完成的新手任务逐个 POST /api/v1/onboarding/tasks/complete {key}（幂等）
 *   · POST /api/v1/points/first-login（首次登录奖励，幂等）
 *   · 打工奖励：**只在本地能找到客户端记录的真实活动数据时**复算档位并
 *     POST /api/v1/pet-work/rewards；本地没有数据就只报告、不领取。
 *     —— 绝不凭空构造 reachedTierId 去骗奖励。
 *
 * 用法：
 *   node daily-tasks.mjs                 # 只读检查（推荐先跑这个）
 *   node daily-tasks.mjs --apply         # 领取可合法领取的奖励
 *   node daily-tasks.mjs --json          # 机器可读输出（供面板/脚本消费）
 *   node daily-tasks.mjs --raw           # 打印上游原始 JSON（调试用）
 *   node daily-tasks.mjs --account=138****0000
 *
 * 环境变量与反代一致：LOOMY_UPSTREAM / LOOMY_PUBLIC / LOOMY_ACCOUNTS_DIR /
 * LOOMY_SESSION_FILES / LOOMY_DAILY_TIMEOUT
 */
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'
import { buildLoomyHeaders } from './lib/loomy-client.mjs'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const VERSION = '1.1.0'

const num = (v, d) => {
  if (v === null || v === undefined || v === '') return d
  const n = Number(v)
  return Number.isFinite(n) ? n : d
}

const CONFIG = {
  upstream: String(process.env.LOOMY_UPSTREAM || 'https://loomyad.xunfei.cn/api/v1').replace(/\/+$/, ''),
  publicDir: process.env.LOOMY_PUBLIC || 'C:\\Users\\Public\\Loomy',
  accountsDir: process.env.LOOMY_ACCOUNTS_DIR || path.join(__dirname, 'accounts'),
  extraFiles: String(process.env.LOOMY_SESSION_FILES || '').split(path.delimiter).filter(Boolean),
  stateFile: process.env.LOOMY_DAILY_STATE || path.join(__dirname, 'daily-tasks-state.json'),
  logDir: path.join(__dirname, 'logs'),
  // 上游抖动很大（实测 pet-work 0.06s~17s，points/records 22s~53s），默认给足
  timeoutMs: num(process.env.LOOMY_DAILY_TIMEOUT, 60) * 1000,
  slowTimeoutMs: num(process.env.LOOMY_DAILY_SLOW_TIMEOUT, 120) * 1000,
}

const ARGS = { apply: false, json: false, raw: false, account: '', help: false }
for (const arg of process.argv.slice(2)) {
  const m = /^--([a-z0-9-]+)(?:=(.*))?$/i.exec(arg)
  if (!m) continue
  const key = m[1].toLowerCase()
  const val = m[2] === undefined ? true : m[2]
  if (key === 'apply') ARGS.apply = true
  else if (key === 'json') ARGS.json = true
  else if (key === 'raw') ARGS.raw = true
  else if (key === 'account') ARGS.account = String(val)
  else if (key === 'help' || key === 'h') ARGS.help = true
  else if (key === 'timeout') CONFIG.timeoutMs = num(val, 30) * 1000
}

// ---------------------------------------------------------------- 脱敏
const mask = (s, head = 6, tail = 4) => {
  const v = String(s || '')
  if (!v) return ''
  if (v.length <= head + tail) return v.slice(0, 2) + '…'
  return `${v.slice(0, head)}…${v.slice(-tail)}`
}
const maskPhone = (p) => String(p || '').replace(/^(\d{3})\d{4}(\d{4})$/, '$1****$2')
const accountIdOf = (session, userid) =>
  'acc_' + crypto.createHash('sha1').update(`${userid || ''}:${session || ''}`).digest('hex').slice(0, 10)

const say = (msg) => {
  if (!ARGS.json) console.log(msg)
}
const appendLog = (line) => {
  try {
    fs.mkdirSync(CONFIG.logDir, { recursive: true })
    fs.appendFileSync(path.join(CONFIG.logDir, 'daily-tasks.log'), `[${new Date().toISOString()}] ${line}\n`)
  } catch { /* 日志失败不影响主流程 */ }
}

// ---------------------------------------------------------------- 会话发现
function readSessionFile(file, source, label) {
  try {
    const raw = JSON.parse(fs.readFileSync(file, 'utf8'))
    const session = String(raw.session || '').trim()
    if (!session) return null
    return {
      id: accountIdOf(session, raw.userid),
      label: label || path.basename(path.dirname(file)),
      source,
      file,
      session,
      userid: String(raw.userid || ''),
      phone: String(raw.phone || ''),
      updatedAt: num(raw.updatedAt, 0),
    }
  } catch {
    return null
  }
}

function discoverSessions() {
  const found = []
  // 1) 桌面客户端授权文件（反代同款路径）
  try {
    for (const dir of fs.readdirSync(CONFIG.publicDir, { withFileTypes: true })) {
      if (!dir.isDirectory()) continue
      const file = path.join(CONFIG.publicDir, dir.name, 'userData', 'auth-session.json')
      const seed = readSessionFile(file, 'desktop', `desktop:${dir.name.slice(0, 6)}`)
      if (seed) found.push(seed)
    }
  } catch { /* 没有桌面客户端就跳过 */ }
  // 2) 本项目的网页登录产物 + accounts/*.json + LOOMY_SESSION_FILES
  const webFile = path.join(__dirname, 'web-session.json')
  const candidates = [webFile, ...CONFIG.extraFiles]
  try {
    for (const f of fs.readdirSync(CONFIG.accountsDir)) {
      if (f.toLowerCase().endsWith('.json')) candidates.push(path.join(CONFIG.accountsDir, f))
    }
  } catch { /* 没有 accounts 目录也正常 */ }
  for (const file of candidates) {
    if (!file || !fs.existsSync(file)) continue
    let raw = {}
    try { raw = JSON.parse(fs.readFileSync(file, 'utf8')) || {} } catch { raw = {} }
    // web-session.json 必须带 kind:'gateway-session'：legacy/web-login.mjs 写的网页 cookie
    // 会话打网关必然 100002，采纳它只会污染签到结果。
    const adoptable = file !== webFile || String(raw.kind || '') === 'gateway-session'
    if (!adoptable) continue
    const seed = readSessionFile(file, file === webFile ? 'web' : 'file', path.basename(file))
    if (seed) found.push(seed)
  }
  // 按 session 去重；再按 userid 去重（同一账号的桌面/网页两个会话只算一个，留更新的）
  const bySession = new Map()
  const sourceRank = { desktop: 3, web: 2, file: 1 }
  for (const seed of found) {
    const prev = bySession.get(seed.session)
    if (!prev || (sourceRank[seed.source] || 0) > (sourceRank[prev.source] || 0)) bySession.set(seed.session, seed)
  }
  const byUser = new Map()
  const out = []
  for (const seed of bySession.values()) {
    const key = seed.userid || seed.id
    const prev = byUser.get(key)
    if (!prev) { byUser.set(key, seed); continue }
    if ((seed.updatedAt || 0) > (prev.updatedAt || 0)) {
      out[out.indexOf(prev)] = seed
      byUser.set(key, seed)
    }
  }
  for (const seed of byUser.values()) if (!out.includes(seed)) out.push(seed)
  return out
}

// ---------------------------------------------------------------- 上游请求
class ApiError extends Error {
  constructor(code, desc, status) {
    super(`${code || status}: ${desc || ''}`.trim())
    this.code = String(code || '')
    this.desc = String(desc || '')
    this.status = status
  }
}

async function api(acc, apiPath, { method = 'GET', body, timeoutMs = CONFIG.timeoutMs } = {}) {
  const ctl = new AbortController()
  const timer = setTimeout(() => ctl.abort(), timeoutMs)
  const t0 = Date.now()
  try {
    const res = await fetch(`${CONFIG.upstream}${apiPath}`, {
      method,
      headers: buildLoomyHeaders({
        session: acc.session,
        accept: 'application/json',
        contentType: body === undefined ? '' : 'application/json',
      }),
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: ctl.signal,
    })
    const text = await res.text()
    let parsed
    try { parsed = JSON.parse(text) } catch { throw new ApiError('', `非 JSON 响应（HTTP ${res.status}）：${mask(text, 60, 20)}`, res.status) }
    if (parsed?.code !== '000000') throw new ApiError(parsed?.code, parsed?.desc, res.status)
    return { data: parsed.data, ms: Date.now() - t0, raw: parsed }
  } catch (err) {
    if (err instanceof ApiError) throw err
    const msg = err?.name === 'AbortError' ? `超时（${Math.round(timeoutMs / 1000)}s）` : String(err?.message || err)
    throw new ApiError('', msg, 0)
  } finally {
    clearTimeout(timer)
  }
}

// ---------------------------------------------------------------- 数据归一化
const isDone = (t) =>
  t?.completed === true || t?.isCompleted === true || t?.finished === true ||
  String(t?.status || '').toLowerCase() === 'completed' || Boolean(t?.completedAt)

// 客户端新手任务注册表（recon 自 Loomy 客户端 onboarding 配置，用于展示名称与分值）。
// 上游 /onboarding/tasks 只返回 {key: 是否完成} 的布尔表 + earned/total 总分，不带标题。
const TASK_META = {
  first_message: { title: '首次对话', points: 500 },
  pick_skill: { title: '选择技能', points: 1000 },
  generate_ppt: { title: '生成 PPT', points: 1500 },
  set_schedule: { title: '设置定时任务', points: 1000 },
  install_skill: { title: '安装技能', points: 1500 },
  configure_remote: { title: '配置远程设备', points: 1000 },
  create_soul: { title: '创建 Soul', points: 1500 },
  share_soul: { title: '分享 Soul', points: 2000 },
}

function normOnboarding(data) {
  // 实测形状：data = { tasks: { key: true|false, ... }, earned: 10000, total: 10000 }
  const raw = data?.tasks
  let entries = []
  if (Array.isArray(raw)) {
    entries = raw.map((t) => ({
      key: String(t?.key || t?.taskKey || t?.id || ''),
      title: String(t?.title || t?.name || ''),
      points: num(t?.points ?? t?.rewardPoints, 0),
      completed: isDone(t),
    }))
  } else if (raw && typeof raw === 'object') {
    entries = Object.entries(raw).map(([key, val]) => {
      const meta = TASK_META[key] || {}
      const completed = typeof val === 'object' && val !== null ? isDone(val) : Boolean(val)
      return { key, title: meta.title || key, points: num(meta.points, 0), completed }
    })
  } else if (Array.isArray(data)) {
    entries = data.map((t) => ({
      key: String(t?.key || t?.id || ''),
      title: String(t?.title || t?.name || ''),
      points: num(t?.points, 0),
      completed: isDone(t),
    }))
  }
  const tasks = entries.filter((t) => t.key).sort((a, b) => a.key.localeCompare(b.key))
  const earned = num(data?.earned ?? data?.earnedPoints, null)
  const donePts = tasks.filter((t) => t.completed).reduce((s, t) => s + t.points, 0)
  return {
    tasks,
    done: tasks.filter((t) => t.completed).length,
    total: tasks.length,
    earnedPoints: earned === null ? donePts : earned,
    totalPoints: num(data?.total, tasks.reduce((s, t) => s + t.points, 0)),
  }
}

function normPetWork(data) {
  // 实测形状：data = { enabled, businessDate, config:{version,tiers:[{tierId,score}],defaultSessionBaseline,...}, status:{...} }
  const cfg = data?.config || {}
  const st = data?.status || {}
  return {
    enabled: data?.enabled !== false,
    businessDate: String(data?.businessDate || st?.businessDate || ''),
    earnedPointsToday: num(st?.earnedPointsToday, 0),
    rewardedTierIds: Array.isArray(st?.rewardedTierIds) ? st.rewardedTierIds.map(String) : [],
    dailyRewardCapped: Boolean(st?.dailyRewardCapped),
    lastGrant: st?.lastGrant || null,
    configVersion: String(cfg?.version || ''),
    dailyMaxPoints: num(cfg?.dailyMaxPoints, null),
    tiers: Array.isArray(cfg?.tiers)
      ? cfg.tiers.map((t) => ({ id: String(t?.tierId || t?.id || ''), score: num(t?.score, 0) }))
        .filter((t) => t.id).sort((a, b) => a.score - b.score)
      : [],
    weights: {
      sessionWeight: num(cfg?.sessionWeight, 0.4),
      depthWeight: num(cfg?.depthWeight, 0.6),
      maxSessionIndex: num(cfg?.maxSessionIndex, 2),
      maxDepthIndex: num(cfg?.maxDepthIndex, 2),
      defaultSessionBaseline: num(cfg?.defaultSessionBaseline, 2),
      defaultDepthBaseline: num(cfg?.defaultDepthBaseline, 4),
      minimumSessionBaseline: num(cfg?.minimumSessionBaseline, 1),
      minimumDepthBaseline: num(cfg?.minimumDepthBaseline, 1),
    },
  }
}

function normBalance(data) {
  return {
    balance: num(data?.balance, null),
    dailyBalance: num(data?.dailyBalance, null),
    availableBalance: num(data?.availableBalance, null),
    total: num(data?.total, null),
  }
}

/**
 * 本地打工活动复算（诚实路径）：只有客户端在本地记了今天的活动量，才据此算档位。
 * 找不到就返回 null —— 不猜、不造。
 */
function localPetWorkActivity() {
  const hits = []
  const wanted = /pet-?work|petwork/i
  try {
    for (const dir of fs.readdirSync(CONFIG.publicDir, { withFileTypes: true })) {
      if (!dir.isDirectory()) continue
      const userData = path.join(CONFIG.publicDir, dir.name, 'userData')
      let files = []
      try { files = fs.readdirSync(userData) } catch { continue }
      for (const f of files) {
        if (!wanted.test(f) || !f.toLowerCase().endsWith('.json')) continue
        const full = path.join(userData, f)
        try {
          const raw = JSON.parse(fs.readFileSync(full, 'utf8'))
          hits.push({ file: full, raw })
        } catch { /* 忽略坏文件 */ }
      }
    }
  } catch { /* 无桌面目录 */ }
  return hits.length ? hits : null
}

function computeReachedTier(hits, petwork) {
  const w = petwork.weights
  for (const hit of hits) {
    const raw = hit.raw || {}
    const day = String(raw.businessDate || raw.date || '')
    if (petwork.businessDate && day && day !== petwork.businessDate) continue
    const activeSessionCount = num(raw.activeSessionCount, null)
    const extraValidTurnCount = num(raw.extraValidTurnCount, null)
    if (activeSessionCount === null || extraValidTurnCount === null) continue
    // 基线：本地有记录就用本地，否则用上游 config 的默认基线（再按 minimum 下限夹紧）
    const sessionBaseline = Math.max(w.minimumSessionBaseline, num(raw.sessionBaseline, w.defaultSessionBaseline))
    const depthBaseline = Math.max(w.minimumDepthBaseline, num(raw.depthBaseline, w.defaultDepthBaseline))
    const sessionIndex = Math.min(activeSessionCount / sessionBaseline, w.maxSessionIndex)
    const depthIndex = Math.min(extraValidTurnCount / depthBaseline, w.maxDepthIndex)
    const score = Math.round((sessionIndex * w.sessionWeight + depthIndex * w.depthWeight) * 100)
    const reached = petwork.tiers.filter((t) => score >= t.score).pop() || null
    return { file: hit.file, activeSessionCount, extraValidTurnCount, sessionBaseline, depthBaseline, score, reachedTierId: reached?.id || null }
  }
  return null
}

// ---------------------------------------------------------------- 单账号检查
async function checkAccount(acc, { apply }) {
  const result = { id: acc.id, label: acc.label, source: acc.source, phone: maskPhone(acc.phone), userid: mask(acc.userid, 6, 3), actions: [], skipped: [], errors: [] }
  const step = async (name, fn) => {
    try {
      const r = await fn()
      return r
    } catch (err) {
      result.errors.push(`${name}: ${err?.message || err}`)
      return null
    }
  }

  const onboarding = await step('新手任务', async () => {
    const { data, ms } = await api(acc, '/onboarding/tasks')
    const n = normOnboarding(data)
    say(`  · 新手任务：${n.done}/${n.total} 完成，已得 ${n.earnedPoints}/${n.totalPoints} 分（${Math.round(ms / 1000)}s）`)
    if (apply) {
      for (const t of n.tasks) {
        if (t.completed) continue
        try {
          const r = await api(acc, '/onboarding/tasks/complete', { method: 'POST', body: { key: t.key } })
          const already = Boolean(r?.data?.alreadyCompleted)
          result.actions.push(`新手任务 ${t.key}${already ? '（原本已完成）' : ` +${t.points}`}`)
          say(`    → 领取 ${t.key}：${already ? '无需重复领取' : '已领取'}`)
        } catch (err) {
          result.errors.push(`领取 ${t.key}: ${err?.message || err}`)
          say(`    → 领取 ${t.key} 失败：${err?.message || err}`)
        }
      }
    } else if (n.total > n.done) {
      say(`    （还有 ${n.total - n.done} 个未完成，加 --apply 可领取）`)
    }
    return n
  })

  const petwork = await step('打工奖励', async () => {
    const { data, ms } = await api(acc, '/pet-work')
    const p = normPetWork(data)
    say(`  · 今日打工：已得 ${p.earnedPointsToday} 分，已领档位 [${p.rewardedTierIds.join(', ') || '无'}]，封顶=${p.dailyRewardCapped}（${Math.round(ms / 1000)}s）`)
    if (apply && p.enabled && !p.dailyRewardCapped) {
      const hits = localPetWorkActivity()
      const calc = hits ? computeReachedTier(hits, p) : null
      if (!calc) {
        say('    → 本地没有客户端打工活动记录，跳过领取（不伪造活动数据）')
        result.skipped.push('打工奖励：本地无活动数据，跳过（不伪造）')
      } else if (!calc.reachedTierId || p.rewardedTierIds.includes(calc.reachedTierId)) {
        say(`    → 本地活动复算档位 ${calc.reachedTierId || '未达标'}，无需领取（score=${calc.score}）`)
        result.skipped.push(`打工奖励：档位 ${calc.reachedTierId || '未达标'} 无需领取`)
      } else {
        try {
          await api(acc, '/pet-work/rewards', {
            method: 'POST',
            body: { businessDate: p.businessDate, configVersion: p.configVersion, reachedTierId: calc.reachedTierId },
          })
          result.actions.push(`打工奖励 ${calc.reachedTierId}（本地复算 score=${calc.score}）`)
          say(`    → 领取档位 ${calc.reachedTierId}（本地复算 score=${calc.score}）`)
        } catch (err) {
          result.errors.push(`领取打工奖励: ${err?.message || err}`)
          say(`    → 领取档位 ${calc.reachedTierId} 失败：${err?.message || err}`)
        }
      }
    }
    return { ...p, localCalc: null }
  })

  const balance = await step('积分余额', async () => {
    const { data, ms } = await api(acc, '/points/records?pageNo=1&pageSize=1&recordType=all', { timeoutMs: CONFIG.slowTimeoutMs })
    const b = normBalance(data)
    say(`  · 余额：可用 ${b.availableBalance ?? '?'}（今日额度 ${b.dailyBalance ?? '?'} / 累计 ${b.balance ?? '?'}），流水 ${b.total ?? '?'} 条（${Math.round(ms / 1000)}s）`)
    return b
  })

  const activation = await step('激活状态', async () => {
    const { data } = await api(acc, '/points/activation')
    return { activated: Boolean(data?.activated), raw: ARGS.raw ? data : undefined }
  })

  if (apply) {
    try {
      await api(acc, '/points/first-login', { method: 'POST', body: {} })
      result.actions.push('首次登录奖励已确认（幂等）')
      say('  · 首次登录奖励：已确认（幂等接口）')
    } catch (err) {
      result.errors.push(`first-login: ${err?.message || err}`)
    }
  }

  result.balance = balance
  result.onboarding = onboarding
  result.petwork = petwork
  result.activation = activation
  result.ok = !(onboarding === null && petwork === null && balance === null)
  return result
}

// ---------------------------------------------------------------- 主流程
async function main() {
  if (ARGS.help) {
    console.log(`loomy daily-tasks v${VERSION}
用法：node daily-tasks.mjs [--apply] [--json] [--raw] [--account=<id|手机号|userid>]
  --apply   执行可合法执行的写操作（新手任务/首次登录/已达成档位的打工奖励）
  --json    只输出 JSON（供面板消费）
  --raw     输出上游原始 JSON（调试）
默认只读检查，不做任何写操作。`)
    return
  }

  const allSessions = discoverSessions()
  const sessions = allSessions.filter((s) => {
    if (!ARGS.account) return true
    const needle = ARGS.account.replace(/\*/g, '')
    return s.id.includes(ARGS.account) || s.userid.includes(needle) ||
      maskPhone(s.phone).replace(/\*/g, '').includes(needle)
  })

  if (!sessions.length) {
    // 区分「一个会话都没有」和「--account 过滤后为空」，否则打错参数会得到误导性提示
    const msg = allSessions.length
      ? `没有匹配 --account=${ARGS.account} 的账号（已发现 ${allSessions.length} 个会话：${allSessions.map((s) => s.id).join(', ')}）`
      : '没有找到任何 Loomy 会话：请先跑 start-loomy-login.cmd 用网页登录，或确认桌面客户端已登录。'
    if (ARGS.json) console.log(JSON.stringify({ ok: false, version: VERSION, error: msg, accounts: [] }, null, 2))
    else console.log(`[daily-tasks] ${msg}`)
    process.exitCode = 1
    return
  }

  if (!ARGS.json) {
    console.log(`[daily-tasks] v${VERSION} · ${ARGS.apply ? '执行模式（会写数据）' : '只读检查'} · ${sessions.length} 个账号 · 上游 ${CONFIG.upstream}`)
  }

  const results = []
  for (const acc of sessions) {
    say(`\n账号 ${acc.id}（${acc.label}，${maskPhone(acc.phone) || acc.source}）`)
    results.push(await checkAccount(acc, { apply: ARGS.apply }))
  }

  const state = {
    version: VERSION,
    ranAt: new Date().toISOString(),
    mode: ARGS.apply ? 'apply' : 'check',
    upstream: CONFIG.upstream,
    accounts: results.map((r) => ({
      id: r.id, label: r.label, source: r.source, phone: r.phone, userid: r.userid,
      ok: r.ok, balance: r.balance, onboarding: r.onboarding, petwork: r.petwork,
      activation: r.activation, actions: r.actions, skipped: r.skipped, errors: r.errors,
    })),
    summary: {
      accounts: results.length,
      ok: results.filter((r) => r.ok).length,
      onboardingDone: results.reduce((s, r) => s + (r.onboarding?.done || 0), 0),
      onboardingTotal: results.reduce((s, r) => s + (r.onboarding?.total || 0), 0),
      availableBalance: results.reduce((s, r) => s + (r.balance?.availableBalance || 0), 0),
      actions: results.reduce((s, r) => s + r.actions.length, 0),
      errors: results.reduce((s, r) => s + r.errors.length, 0),
    },
  }
  try {
    fs.writeFileSync(CONFIG.stateFile, JSON.stringify(state, null, 2))
  } catch (err) {
    appendLog(`写入状态文件失败：${err?.message || err}`)
  }
  appendLog(`${state.mode} 完成：账号 ${state.summary.accounts}，任务 ${state.summary.onboardingDone}/${state.summary.onboardingTotal}，可用余额 ${state.summary.availableBalance}，动作 ${state.summary.actions}，错误 ${state.summary.errors}`)

  if (ARGS.json) {
    console.log(JSON.stringify(state, null, 2))
  } else {
    console.log(`\n[daily-tasks] 汇总：${state.summary.ok}/${state.summary.accounts} 账号正常，` +
      `新手任务 ${state.summary.onboardingDone}/${state.summary.onboardingTotal}，可用余额 ${state.summary.availableBalance}，` +
      `本次动作 ${state.summary.actions}，错误 ${state.summary.errors}`)
    if (!ARGS.apply) console.log('[daily-tasks] 这是只读检查；要领取可合法领取的奖励请加 --apply')
    console.log(`[daily-tasks] 状态已写入 ${CONFIG.stateFile}`)
  }
  if (state.summary.ok === 0) process.exitCode = 1
}

main().catch((err) => {
  if (ARGS.json) console.log(JSON.stringify({ ok: false, version: VERSION, error: String(err?.message || err) }, null, 2))
  else console.error(`[daily-tasks] 失败：${err?.stack || err}`)
  process.exitCode = 1
})
