@echo off
rem Start Loomy -> OpenAI compatible reverse proxy (loomy-proxy)
rem Listens on 127.0.0.1:8790, auto-reads Loomy auth-session.json
rem Runs DETACHED and hidden; closing this window does NOT stop it.
rem Logs: logs\proxy.log  /  logs\proxy.err.log      Stop: stop-all.cmd
rem Safe to run repeatedly: exits if already running
setlocal
set "PORT=8790"
set "ROOT=%~dp0"
curl.exe -s -m 2 "http://127.0.0.1:%PORT%/health" >nul 2>&1
if not errorlevel 1 (
  echo [loomy-proxy] already running at http://127.0.0.1:%PORT%
  exit /b 0
)
set "NODE=%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe"
if not exist "%NODE%" set "NODE=node"
cd /d "%ROOT%"
if not exist "%ROOT%logs" mkdir "%ROOT%logs"
"%NODE%" "%ROOT%launch-detached.mjs" "%ROOT%logs\proxy.log" "%ROOT%logs\proxy.err.log" "%ROOT%loomy-proxy.mjs" --port=%PORT%
echo [loomy-proxy] started in background: http://127.0.0.1:%PORT%/health   (log = logs\proxy.log)
