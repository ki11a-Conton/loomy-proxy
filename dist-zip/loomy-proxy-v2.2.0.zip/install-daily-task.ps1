# 注册「每天自动签到」的 Windows 计划任务（可选，默认不启用）
#
# 用 pwsh 7 运行：
#   pwsh -File .\install-daily-task.ps1                 # 注册/更新：每天 09:05 自动执行（只读检查）
#   pwsh -File .\install-daily-task.ps1 -Apply          # 每天 09:05 自动执行并领取可合法领取的奖励
#   pwsh -File .\install-daily-task.ps1 -Time 08:30 -Apply
#   pwsh -File .\install-daily-task.ps1 -Remove         # 删除计划任务
#
# 说明：
#   · 任务只调用本目录的 start-loomy-daily.cmd，不联网下载任何东西，也不写系统目录之外的位置。
#   · 打工奖励只在本地存在客户端真实活动记录时才领取，找不到就跳过（不伪造）。
#   · 如果注册失败（需要管理员权限时），改用「任务计划程序」图形界面手动创建同样即可。
[CmdletBinding()]
param(
  [string]$Time = '09:05',
  [switch]$Apply,
  [switch]$Remove,
  [string]$TaskName = 'LoomyDailyTasks'
)

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$cmd = Join-Path $here 'start-loomy-daily.cmd'
$args = if ($Apply) { '--apply' } else { '' }

if ($Remove) {
  if (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) {
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
    Write-Host "[daily-task] 已删除计划任务 $TaskName"
  } else {
    Write-Host "[daily-task] 计划任务 $TaskName 不存在"
  }
  return
}

if (-not (Test-Path $cmd)) { throw "找不到 $cmd" }

$action = New-ScheduledTaskAction -Execute $cmd -Argument $args -WorkingDirectory $here
$trigger = New-ScheduledTaskTrigger -Daily -At $Time
# 错过时间时尽快补跑；笔记本上电池供电也执行
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Minutes 30)

try {
  Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Settings $settings -Description 'Loomy 每日任务/签到（本目录 daily-tasks.mjs）' -Force | Out-Null
  $mode = if ($Apply) { '执行并领取奖励' } else { '只读检查' }
  Write-Host "[daily-task] 已注册：$TaskName，每天 $Time $mode"
  Write-Host "[daily-task] 立即测试： Start-ScheduledTask -TaskName $TaskName"
  Write-Host "[daily-task] 查看结果： Get-ScheduledTaskInfo -TaskName $TaskName | Format-List"
  Write-Host "[daily-task] 删除：     pwsh -File .\install-daily-task.ps1 -Remove"
} catch {
  Write-Host "[daily-task] 注册失败：$($_.Exception.Message)" -ForegroundColor Yellow
  Write-Host '[daily-task] 可改用「任务计划程序」手动创建：操作=启动程序，程序=' -NoNewline
  Write-Host $cmd -NoNewline
  Write-Host ("，参数=" + $args + "，起始于=" + $here)
}
