#!/usr/bin/env node
/**
 * ⚠️ 已弃用（legacy，2026-10-19）：本脚本走的是「官方网页 cookie 会话」路线，
 * 实测该 cookie 打网关只会得到 {"code":"100002","desc":"登录已失效，请重新登录"}，
 * 因此它写出的 web-session.json 不带 kind:'gateway-session'，反代不会再采纳。
 * 请改用同样零依赖、但复刻客户端短信登录协议的 `web-auth.mjs`（网页登录，127.0.0.1:8791）
 * 或命令行 `node lib/xfyun-account.mjs`。本文件仅作历史参考保留。
 *
 * Loomy 网页版登录 → 拿 session token（零依赖）
 *
 * 原理：loomy.xunfei.cn 的网页版登录接口在 /api/workspace/auth/* 下
 *   POST /api/workspace/auth/sms-code  {phone}                       → data.messageId
 *   POST /api/workspace/auth/login    {phone,code,messageId,...}    → Set-Cookie loomy_web_session
 * 登录成功后用 cookie 值去试网关 loomyad.xunfei.cn（token / Bearer 两种头），
 * 哪个通就把哪个存成 web-session.json，反代 loomy-proxy.mjs 会自动优先读它。
 *
 * 用法：
 *   node web-login.mjs                   交互式：输手机号 → 收验证码 → 输验证码 → 自动验证并存盘
 *   node web-login.mjs send [phone]      只发验证码（phone 省略则取已保存的授权文件里的号码）
 *   node web-login.mjs verify <code>     用上一步的 messageId 完成登录
 *   node web-login.mjs status            查看当前保存的 token 状态
 *   node web-login.mjs logout            删除本地 token
 */

import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline/promises';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const STATE_FILE = path.join(HERE, 'recon', 'web-login-state.json');
const TOKEN_FILE = path.join(HERE, 'web-session.json');

const WEB_BASE = 'https://loomy.xunfei.cn';
const API_BASE = WEB_BASE + '/api/workspace';
const GATEWAY = 'https://loomyad.xunfei.cn/api/v1';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

function readJson(file, fallback = null) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}
function writeJson(file, data) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
}

/** 从桌面客户端授权文件里翻出手机号，作为默认号码 */
function guessPhone() {
  const root = 'C:\\Users\\Public\\Loomy';
  try {
    for (const dir of fs.readdirSync(root)) {
      const f = path.join(root, dir, 'userData', 'auth-session.json');
      const d = readJson(f);
      if (d?.phone) return String(d.phone).replace(/^(\d{3})\d{4}(\d{4})$/, '$1****$2');
    }
  } catch {}
  return '';
}
/** 保存的号码（完整） */
function savedPhone() {
  const s = readJson(STATE_FILE);
  if (s?.phone) return s.phone;
  const root = 'C:\\Users\\Public\\Loomy';
  try {
    for (const dir of fs.readdirSync(root)) {
      const d = readJson(path.join(root, dir, 'userData', 'auth-session.json'));
      if (d?.phone) return String(d.phone);
    }
  } catch {}
  return '';
}

function extractCookies(res) {
  // Node 18+ Headers.getSetCookie()
  const out = [];
  if (typeof res.headers.getSetCookie === 'function') out.push(...res.headers.getSetCookie());
  else {
    const raw = res.headers.get('set-cookie');
    if (raw) out.push(raw);
  }
  return out;
}

async function postJson(url, body, extraHeaders = {}) {
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      accept: 'application/json',
      'user-agent': UA,
      origin: WEB_BASE,
      referer: WEB_BASE + '/login',
      ...extraHeaders,
    },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch {}
  return { status: res.status, json, text, cookies: extractCookies(res) };
}

async function getJson(url, cookie) {
  const res = await fetch(url, {
    headers: {
      accept: 'application/json',
      'user-agent': UA,
      ...(cookie ? { cookie: `loomy_web_session=${cookie}` } : {}),
    },
  });
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch {}
  return { status: res.status, json, text };
}

function cookieValue(setCookies, name) {
  for (const c of setCookies) {
    const m = new RegExp('(?:^|[,\\s])' + name + '=([^;]*)').exec(c);
    if (m && m[1]) return decodeURIComponent(m[1]);
  }
  return '';
}

async function doSend(phone) {
  const r = await postJson(API_BASE + '/auth/sms-code', { phone });
  console.log('[sms-code]', r.status, r.text.slice(0, 300));
  if (r.status !== 200 || !r.json?.success) throw new Error('发送验证码失败');
  const messageId = r.json?.data?.messageId || r.json?.data?.message_id || '';
  writeJson(STATE_FILE, { phone, messageId, sentAt: Date.now() });
  console.log('[ok] messageId =', messageId);
  return { phone, messageId };
}

async function doVerify(code) {
  const st = readJson(STATE_FILE);
  if (!st?.phone) throw new Error('先执行 send 拿 messageId');
  const body = {
    phone: st.phone,
    code,
    messageId: st.messageId,
    channel: '',
    visitedId: '',
    deviceId: 'web_fp_' + Math.random().toString(16).slice(2, 10),
  };
  const r = await postJson(API_BASE + '/auth/login', body);
  console.log('[login]', r.status, r.text.slice(0, 500));
  if (r.status !== 200 || !r.json?.success) throw new Error('登录失败：' + r.text.slice(0, 200));

  const data = r.json.data || {};
  // 可能的 token 字段名（服务端版本差异）
  const direct = data.session || data.token || data.sessionToken || data.accessToken || '';
  const cookie = cookieValue(r.cookies, 'loomy_web_session') || direct;
  if (!cookie) throw new Error('登录成功但没拿到 cookie/token：' + JSON.stringify(data).slice(0, 300));

  // 验证 web session 能否直接打网关（两种头都试）
  const headerModes = { token: { token: cookie }, bearer: { authorization: `Bearer ${cookie}` } };
  const results = {};
  for (const [mode, hdr] of Object.entries(headerModes)) {
    try {
      const res = await fetch(GATEWAY + '/models', {
        headers: { accept: 'application/json', 'user-agent': UA, ...hdr },
      });
      const t = await res.text();
      results[mode] = { status: res.status, ok: res.ok, body: t.slice(0, 160) };
      if (res.ok) break;
    } catch (e) { results[mode] = { status: 0, ok: false, body: String(e.message) }; }
  }
  const me = await getJson(API_BASE + '/auth/me', cookie);

  writeJson(TOKEN_FILE, {
    session: cookie,
    source: 'web-login',
    phone: st.phone,
    userId: data.userid || data.userId || data.user_id || '',
    nickname: data.nickname || '',
    updatedAt: Date.now(),
    gatewayHeader: Object.entries(results).find(([, v]) => v.ok)?.[0] || '',
    gatewayCheck: results,
  });
  console.log('[saved]', TOKEN_FILE);
  console.log('[me]', me.status, JSON.stringify(me.json).slice(0, 300));
  console.log('[gateway]', JSON.stringify(results, null, 2));
  return { cookie, results };
}

async function interactive() {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  try {
    const dflt = savedPhone();
    const hint = dflt ? ` [${dflt.replace(/^(\d{3})\d{4}(\d{4})$/, '$1****$2')}]` : (guessPhone() ? ` [${guessPhone()}]` : '');
    let phone = (await rl.question(`手机号${hint}: `)).trim() || dflt;
    if (!/^1\d{10}$/.test(phone)) throw new Error('手机号格式不对');
    await doSend(phone);
    const code = (await rl.question('短信验证码: ')).trim();
    if (!/^\d{4,6}$/.test(code)) throw new Error('验证码格式不对');
    await doVerify(code);
  } finally { rl.close(); }
}

function status() {
  const t = readJson(TOKEN_FILE);
  const d = readJson(STATE_FILE);
  console.log('token 文件:', TOKEN_FILE, t ? '存在' : '不存在');
  if (t) {
    console.log('  来源:', t.source, '| 手机:', t.phone, '| 网关头:', t.gatewayHeader || '(未验证)');
    console.log('  session:', String(t.session).slice(0, 12) + '…(' + String(t.session).length + ' chars)');
    console.log('  保存于:', new Date(t.updatedAt).toLocaleString('zh-CN'));
    const ageH = (Date.now() - t.updatedAt) / 36e5;
    console.log('  年龄:', ageH.toFixed(1), '小时', ageH > 48 ? '(可能已过期，建议重新登录)' : '');
  }
  if (d) console.log('待验证状态: phone=' + d.phone + ' messageId=' + d.messageId + ' 于 ' + new Date(d.sentAt).toLocaleString('zh-CN'));
}

const [cmd, arg] = process.argv.slice(2);
try {
  if (!cmd) await interactive();
  else if (cmd === 'send') await doSend(arg || savedPhone());
  else if (cmd === 'verify') {
    if (!arg) throw new Error('用法: node web-login.mjs verify <code>');
    await doVerify(arg);
  } else if (cmd === 'status') status();
  else if (cmd === 'logout') {
    fs.rmSync(TOKEN_FILE, { force: true });
    fs.rmSync(STATE_FILE, { force: true });
    console.log('已删除本地 token');
  } else {
    console.log('未知命令，可选: send | verify <code> | status | logout');
    process.exitCode = 1;
  }
} catch (e) {
  console.error('[error]', e.message);
  process.exitCode = 1;
}
