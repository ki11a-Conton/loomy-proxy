#!/usr/bin/env node
/**
 * Loomy -> OpenAI 兼容反向代理（龙虾反代）
 *
 * 上游：https://loomyad.xunfei.cn/api/v1
 * 鉴权（已实测）：
 *   GET  /models            -> header: token: <session>
 *   POST /chat/completions  -> header: Authorization: Bearer <session>
 * session 从 Loomy 客户端授权文件动态读取，客户端重新登录后自动生效。
 *
 * 用法： node loomy-proxy.mjs [--port 8787]
 */
import http from 'node:http'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const WEB_SESSION_FILE = path.join(__dirname, 'web-session.json')

const UPSTREAM = process.env.LOOMY_UPSTREAM || 'https://loomyad.xunfei.cn/api/v1'
const PORT = Number(process.env.PORT || process.argv.find(a => /^--port=/.test(a))?.split('=')[1] || 8787)
const HOST = process.env.HOST || '127.0.0.1'
const LOOMY_PUBLIC = process.env.LOOMY_PUBLIC_DIR || 'C:\\Users\\Public\\Loomy'

const log = (...a) => console.log(new Date().toISOString(), ...a)

/**
 * 读取可用的 session，取「最近更新」的一个：
 *   1) 桌面客户端授权文件  C:\Users\Public\Loomy\<hash>\userData\auth-session.json
 *   2) 网页登录服务写入的  <项目目录>\web-session.json
 * 两者 session 同源（讯飞账号登录态），网关一视同仁。
 */
function readSession() {
  const candidates = []
  // 桌面客户端
  try {
    const dirs = fs.readdirSync(LOOMY_PUBLIC, { withFileTypes: true })
    for (const d of dirs) {
      if (!d.isDirectory()) continue
      const f = path.join(LOOMY_PUBLIC, d.name, 'userData', 'auth-session.json')
      try {
        const st = fs.statSync(f)
        const j = JSON.parse(fs.readFileSync(f, 'utf8'))
        if (j.session) candidates.push({ ...j, mtime: st.mtimeMs, file: f, source: 'desktop-client' })
      } catch { /* ignore */ }
    }
  } catch { /* ignore */ }
  // 网页登录（只认 kind=gateway-session，避免误用官方网页 cookie 会话）
  try {
    const st = fs.statSync(WEB_SESSION_FILE)
    const j = JSON.parse(fs.readFileSync(WEB_SESSION_FILE, 'utf8'))
    if (j.session && j.kind === 'gateway-session') {
      candidates.push({ ...j, mtime: st.mtimeMs, file: WEB_SESSION_FILE, source: 'web-login' })
    }
  } catch { /* ignore */ }
  if (candidates.length === 0) return null
  candidates.sort((a, b) => b.mtime - a.mtime)
  return candidates[0]
}

function sessionHeaders(mode) {
  const s = readSession()
  if (!s) return { ok: false, reason: '未找到 Loomy 授权文件（auth-session.json）' }
  return {
    ok: true,
    session: s,
    headers: mode === 'models'
      ? { token: s.session }
      : { authorization: `Bearer ${s.session}` },
  }
}

const MODEL_ALIAS = {
  'deepseek-v4.1-flash': 'DeepSeek-V4.1-Flash',
  'deepseek-v4-flash': 'deepseek-v4-flash-0731',
}

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj)
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'content-length': Buffer.byteLength(body) })
  res.end(body)
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = []
    req.on('data', c => chunks.push(c))
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')))
    req.on('error', reject)
  })
}

async function proxyModels(res) {
  const auth = sessionHeaders('models')
  if (!auth.ok) return sendJson(res, 503, { error: { message: auth.reason, type: 'loomy_auth' } })
  const r = await fetch(`${UPSTREAM}/models`, { headers: { ...auth.headers, accept: 'application/json' } })
  const text = await r.text()
  let data
  try { data = JSON.parse(text) } catch { return sendJson(res, 502, { error: { message: '上游返回非 JSON', raw: text.slice(0, 300) } }) }
  // 上游成功时返回模型「裸数组」；失败时返回 {code,desc} 对象
  const list = Array.isArray(data) ? data : Array.isArray(data?.data) ? data.data : []
  if (list.length === 0 && data?.code && data.code !== '000000' && data.code !== '0') {
    return sendJson(res, 401, { error: { message: data.desc || '鉴权失败', code: data.code } })
  }
  // 附加小写别名，方便各类客户端
  const extra = list.map(m => ({ ...m, id: String(m.id).toLowerCase() }))
  const seen = new Set(list.map(m => m.id))
  const merged = [...list, ...extra.filter(m => !seen.has(m.id))]
  sendJson(res, 200, { object: 'list', data: merged })
}

async function proxyChat(req, res) {
  const auth = sessionHeaders('chat')
  if (!auth.ok) return sendJson(res, 503, { error: { message: auth.reason, type: 'loomy_auth' } })
  const raw = await readBody(req)
  let payload
  try { payload = JSON.parse(raw || '{}') } catch { return sendJson(res, 400, { error: { message: '请求体不是合法 JSON' } }) }
  if (payload.model && MODEL_ALIAS[String(payload.model).toLowerCase()]) payload.model = MODEL_ALIAS[String(payload.model).toLowerCase()]

  const controller = new AbortController()
  req.on('close', () => controller.abort())
  let upstream
  try {
    upstream = await fetch(`${UPSTREAM}/chat/completions`, {
      method: 'POST',
      headers: { ...auth.headers, 'content-type': 'application/json', accept: payload.stream ? 'text/event-stream' : 'application/json' },
      body: JSON.stringify(payload),
      signal: controller.signal,
    })
  } catch (e) {
    return sendJson(res, 502, { error: { message: `上游连接失败: ${e.message}` } })
  }
  const ctype = upstream.headers.get('content-type') || (payload.stream ? 'text/event-stream; charset=utf-8' : 'application/json; charset=utf-8')
  res.writeHead(upstream.status, { 'content-type': ctype, 'cache-control': 'no-cache', 'x-accel-buffering': 'no' })
  if (!upstream.body) { res.end(); return }
  try {
    for await (const chunk of upstream.body) res.write(chunk)
    res.end()
  } catch (e) {
    res.end()
  }
}

async function proxyRaw(req, res, method, rest) {
  // 其它 OpenAI 兼容透传：/v1/embeddings 等，统一带 Bearer
  const auth = sessionHeaders('chat')
  if (!auth.ok) return sendJson(res, 503, { error: { message: auth.reason, type: 'loomy_auth' } })
  const body = method === 'GET' || method === 'HEAD' ? undefined : await readBody(req)
  const r = await fetch(`${UPSTREAM}${rest}`, {
    method,
    headers: { ...auth.headers, 'content-type': req.headers['content-type'] || 'application/json', accept: req.headers.accept || '*/*' },
    body,
  })
  const buf = Buffer.from(await r.arrayBuffer())
  res.writeHead(r.status, { 'content-type': r.headers.get('content-type') || 'application/json' })
  res.end(buf)
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || `${HOST}:${PORT}`}`)
  let p = url.pathname
  if (p === '/health' || p === '/') {
    const s = readSession()
    return sendJson(res, 200, {
      ok: true,
      auth_file: s?.file || null,
      auth_source: s?.source || null,
      userid: s?.userid || null,
      phone: s?.phone || null,
      upstream: UPSTREAM,
    })
  }
  // 同时接受 /v1/... 与裸路径
  if (p.startsWith('/v1')) p = p.slice(3)
  if (p === '/models' && req.method === 'GET') {
    try { return await proxyModels(res) } catch (e) { return sendJson(res, 502, { error: { message: e.message } }) }
  }
  if (p === '/chat/completions' && req.method === 'POST') {
    try { return await proxyChat(req, res) } catch (e) { return sendJson(res, 502, { error: { message: e.message } }) }
  }
  const rest = p.replace(/^\//, '')
  try { return await proxyRaw(req, res, req.method, rest) } catch (e) { return sendJson(res, 502, { error: { message: e.message } }) }
})

server.listen(PORT, HOST, () => {
  const s = readSession()
  log(`loomy-proxy listening http://${HOST}:${PORT}  upstream=${UPSTREAM}`)
  log(s
    ? `session: ${s.session.slice(0, 8)}... source=${s.source} userid=${s.userid} phone=${s.phone}`
    : '警告: 尚未找到可用 session —— 请先在桌面客户端登录，或运行 node web-auth.mjs 网页登录')
})
