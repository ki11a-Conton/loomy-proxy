# 龙虾反代 v2.1.2 · Loomy 授权态 → OpenAI 兼容本地接口

> **版本说明**：v2.1.2 = v2.1.0 服务代码 + 后台启动器（`launch-detached.mjs`：detached 进程 + 文件日志，关窗口不会停服务）+ `stop-all.cmd` + 文档更新，**服务逻辑无改动**（`/health` 里 `version` 仍返回 `2.1.0`）。

把 **Loomy（讯飞）桌面客户端的登录授权**封装成一个跑在你自己电脑上的 **OpenAI 兼容反代**：任何说 OpenAI 协议的客户端（DeepSeek Harness、Cline、Cherry Studio、`curl`……）把 `baseURL` 指向 `http://127.0.0.1:8790/v1`，就能用你自己 Loomy 账号的额度调用 `DeepSeek-V4.1-Flash` 等模型（含流式与 function calling）。

**纯 Node 单文件实现，零第三方依赖，不需要 Docker，不需要 Python。** 解压 → 拿到 session → 双击一个 `.cmd`，就能用。

| 能力 | 说明 |
| --- | --- |
| OpenAI 兼容接口 | `GET /v1/models`、`POST /v1/chat/completions`（流式 / 非流式 / tools / reasoning_effort） |
| 多账号池 | 自动发现桌面客户端授权文件、网页登录 session、手动放置的账号 JSON；同一账号多 session 互为备份 |
| 额度感知选号 | 平滑加权轮询（SWRR）：权重 = 额度份额 × 健康度 × 空闲度 ÷ (1+并发) |
| 故障转移 | 鉴权失效标记重登、429 软冷却、5xx 熔断、请求级跨账号重试（只在首字节前） |
| 双鉴权头注入 | 上游 `/models` 只认 `token:`、`/chat/completions` 只认 `Authorization: Bearer`，反代对每个请求同时发两个头 |
| 模型别名 | 大小写不敏感，`deepseek-v4.1-flash` → 上游 `DeepSeek-V4.1-Flash` |
| 可观测 | `/health`、`/credit` 额度快照、`/admin` 网页面板、日志全程脱敏 |
| 网页登录（可选） | `web-auth.mjs` @ `127.0.0.1:8791`：手机号 + 短信验证码换同源 session，不用装 Loomy 客户端 |
| 每日任务（可选） | `daily-tasks.mjs`：新手任务完成度、打工奖励、余额快照；默认只读检查，`--apply` 才写，且**拒绝伪造奖励数据** |
| 安全 | 所有服务只监听 `127.0.0.1`；不附带任何凭据文件，session 由你自己产生 |

---

## 一、这是什么项目

### 背景

Loomy 桌面客户端（Windows）通过一个 OpenAI 兼容的模型网关 `https://loomyad.xunfei.cn/api/v1` 调用模型。它有两个特点让人没法直接拿它当 API 用：

1. **登录态只存在本机客户端里**：登录后客户端把 `{"session": "<32位hex>", "userid", "phone"}` 写到
   `C:\Users\Public\Loomy\<用户hash>\userData\auth-session.json`。这个 `session` 就是上游 token。
2. **鉴权头是分裂的**（实测）：

   | 请求 | 使用的头 | 结果 |
   | --- | --- | --- |
   | `GET /models` | `token: <session>` | ✅ 200 |
   | `GET /models` | `Authorization: Bearer <session>` | ❌ `{"code":"100002","desc":"缺少 token"}` |
   | `POST /chat/completions` | `token: <session>` | ❌ `缺少 token` |
   | `POST /chat/completions` | `Authorization: Bearer <session>` | ✅ 200 |
   | 两个头都带 | —— | ✅ 正常（推荐） |

   也就是说：**列表接口认 `token` 头，补全接口认 `Bearer` 头，两者不通用。**

任何现成的 OpenAI 客户端都只会发 `Authorization: Bearer <API key>`，既不会去读桌面客户端的授权文件，也不会为不同路径切换头。所以需要一个本地中间层把这些差异全部吃掉。

### 这个项目做了什么

| 组件 | 端口 | 干什么 |
| --- | --- | --- |
| `loomy-proxy.mjs` | 8790 | **反代主体**。维护账号池、按额度/健康度选号、故障转移、对每个上游请求同时注入两个鉴权头，把网关包装成标准 OpenAI 接口 |
| `web-auth.mjs` | 8791 | **网页登录**。复刻客户端登录协议（讯飞账号 API + HMAC-SHA1 签名），用手机号 + 短信验证码直接换到与客户端同源的 session，写到 `web-session.json` |
| `daily-tasks.mjs` | —（CLI） | **每日任务**。新手任务完成度检查、每日打工奖励领取、余额与今日额度快照 |

它**不是**破解、也**不是**共享账号：session 来自你自己账号的合法授权（客户端登录或自己的手机短信验证码），额度是你自己账号的积分。

### 架构

```
┌────────────────────────┐          ┌──────────────────────────────┐          ┌────────────────────────────────┐
│  任意 OpenAI 兼容客户端  │  HTTP    │  loomy-proxy.mjs  v2.1.0     │  HTTPS   │  https://loomyad.xunfei.cn      │
│   · DeepSeek Harness   │ ───────▶ │  127.0.0.1:8790/v1           │ ───────▶ │  /api/v1   （OpenAI 兼容网关）   │
│   · curl / Cline / …   │          │  · 账号池 + 额度感知选号       │          │  模型：DeepSeek-V4.1-Flash 等   │
└────────────────────────┘          │  · 熔断 / 故障转移 / 模型别名   │          └────────────────────────────────┘
                                    │  · 每个请求同时注入 token + Bearer │
                                    └──────────────┬───────────────┘
                                                   │ 只读读取 session
              ┌────────────────────────────────────┼─────────────────────────────────────┐
              ▼                                    ▼                                     ▼
   web-session.json                    C:\Users\Public\Loomy\*\userData\          accounts\*.json
   （网页登录写入，8791）                auth-session.json（桌面客户端写入）          （手动放置）
```

上游是**无状态**的 OpenAI 兼容网关（每次请求都带完整 `messages`，没有服务端会话 ID），所以跨账号轮询不会丢上下文——这也是本项目**有意不做会话粘性**的原因。

---

## 二、怎么部署到本地

### 环境要求

| 项目 | 要求 |
| --- | --- |
| 操作系统 | Windows 10 / 11（x64）。三个组件都是纯 Node，理论上 macOS / Linux 也能跑，但启动脚本是 `.cmd`，需要自己改 |
| Node.js | **22 或更高**（项目里用到 `AbortSignal.timeout`、`fetch`、ESM 等；实测 Node 24 可用）。`node -v` 检查 |
| 第三方依赖 | **无**。不用 `npm install` |
| Docker / Python | **不需要** |
| 磁盘 | 约 100 KB |
| 网络 | 能直连 `https://loomyad.xunfei.cn` 与 `https://account.xfinfr.com` |

### 1. 解压

解压到任意目录，例如 `D:\loomy-proxy\`。下文用当前目录里的文件名指代，命令都在**解压后的根目录**执行。

### 2. 确认 Node

```powershell
node -v      # 需要 v22.x 或更高
```

若提示找不到 `node`：装一个 Node 22+ 并加入 PATH。启动脚本会**优先复用 DeepSeek Harness 自带的 node**，找不到才回退到 PATH 里的 `node`。

### 3. 拿到 session（三选一，可叠加）

账号池支持多个来源，**同一个账号的多个 session 会互为候选**，15 秒自动重扫一次，重新登录后无需重启反代。

#### 方式 A：网页登录（不用装 Loomy 客户端）

```powershell
.\start-loomy-login.cmd
```

浏览器会自动打开 `http://127.0.0.1:8791`：填手机号 → 「发送验证码」→ 填 6 位短信码 → 「登录并获取 token」。成功后页面显示打码 session、userid 与**网关校验结果**，并写入 `web-session.json`：

```json
{
  "kind": "gateway-session",
  "session": "<32位hex，与桌面客户端同源>",
  "phone": "<打码手机号>",
  "userid": "<你的 userid>",
  "source": "xfyun-sms-web",
  "gateway": { "ok": true, "modelCount": 12 }
}
```

> `kind: "gateway-session"` 这个标记是必须的：反代只认带此标记的 `web-session.json`，用来挡住旧脚本写进来的官方网页 cookie 会话（那种会话打网关必然 `100002`）。

**网页登录需要客户端凭据**（appid / AccessKey）。`lib/xfyun-account.mjs` 会按顺序找 `.env.prod`：

1. 环境变量 `LOOMY_ENV_PATH` 指定的路径；
2. `secrets\loomy.env.enc`（客户端 `.env.prod` 的加密副本，AES-256-GCM + scrypt）；
3. `secrets\.env.prod`（明文）；
4. 已安装的 Loomy 客户端：`%LOCALAPPDATA%\Programs\loomy\resources\.env.prod`（常见路径之一，脚本还会试 `Loomy` 大小写变体与 `%ProgramFiles%\Loomy\...`）。

> **本压缩包刻意不含任何凭据文件**（`secrets/` 已排除）。所以：
> - 机器上装了 Loomy 客户端 → 网页登录开箱可用（脚本自己去客户端目录找）；
> - 没装客户端 → 把客户端安装目录 `resources\.env.prod` 拷到 `secrets\.env.prod`，或 `$env:LOOMY_ENV_PATH='C:\path\to\.env.prod'` 后启动。
>
> 找不到时会明确报错：`未找到 Loomy 环境文件（.env.prod）`。这些凭据等同于客户端身份，**不要外传、不要提交到 Git**。

#### 方式 B：桌面客户端已有登录态（最省事）

装了 Loomy 客户端并登录过，`auth-session.json` 已经在
`C:\Users\Public\Loomy\<用户hash>\userData\auth-session.json`。
反代启动时会自动扫描这个位置，**什么都不用配**。

#### 方式 C：手动放账号

在根目录建 `accounts\` 目录，往里放任意多个 JSON 文件：

```json
{ "session": "<32位hex>", "userid": "<你的 userid>", "phone": "<打码手机号>" }
```

或者用环境变量 `LOOMY_SESSION_FILES` 指向别处的 session 文件（多个用 `;` 分隔）：

```powershell
$env:LOOMY_SESSION_FILES='D:\sessions\a.json;D:\sessions\b.json'
```

### 4. 启动与停止

```powershell
.\start-all.cmd           # 推荐：反代 8790 + 网页登录服务 8791 一起拉起（幂等）
.\start-loomy-proxy.cmd   # 也可以只启反代
.\stop-all.cmd            # 停止两个服务
```

脚本是幂等的：已经在跑就只提示不重复启动。`start-all.cmd` 会把两个服务都补齐（缺哪个启哪个），结束后打印两边 health 并停住等你看；加 `--no-pause` 则不等待回车，适合计划任务/脚本调用。

两个服务都由 `launch-detached.mjs` 以 **detached（脱离控制台）进程 + 文件日志** 拉起，所以：

- **关掉启动窗口/终端不会停服务**，也不会再弹常驻窗口；
- 日志固定写在 `logs\proxy.log`、`logs\proxy.err.log`、`logs\web-auth.log`（只追加，不轮转）；
- 想停就用 `.\stop-all.cmd`（按 8790/8791 的监听进程精确停，不误杀别的 node）。

实时看日志：

```powershell
Get-Content .\logs\proxy.log -Tail 20 -Wait
```

手动前台启动（调试用，会占用当前窗口）：

```powershell
node loomy-proxy.mjs                 # 默认 127.0.0.1:8790
node loomy-proxy.mjs --port=8790     # 显式指定端口
```

### 5. 自检

```powershell
curl.exe -s http://127.0.0.1:8790/health
```

返回示例：

```json
{
  "ok": true,
  "service": "loomy-proxy",
  "version": "2.1.0",
  "upstream": "https://loomyad.xunfei.cn/api/v1",
  "mode": "pool",
  "accounts_total": 2,
  "accounts_usable": 2,
  "auth_file": "C:\\Users\\Public\\Loomy\\<hash>\\userData\\auth-session.json",
  "auth_source": "desktop",
  "phone": "138****0000",
  "userid": "123456…789",
  "available_balance": 123.4,
  "model_count": 18,
  "daily_tasks": { "last_run_at": null, "last_mode": null, "running": false }
}
```

`accounts_usable >= 1` 且 `auth_file` 不为 `null` 就是好的（`auth_file` 在**所有账号都失效**时返回 `null`——这是刻意的，避免误以为还有可用授权）。

> 刚启动的几秒内 `available_balance` / `model_count` 可能是 `null`：额度和模型清单是后台异步拉的（上游 `/points/records` 最慢实测 53 秒），稍等再查即可，不影响对话选号。

```powershell
curl.exe -s http://127.0.0.1:8790/v1/models | more
```

到此部署完成。

---

## 三、部署了怎么用

### 3.1 接进 DeepSeek Harness（主要消费方）

编辑 DSH 的 profile 补丁 `C:\Users\<你>\.dsh\profiles\desktop\cordis.patch.yml`，在 `llm-pi-ai.providers` 下加一个 `loomy` 提供方（节选，可按需增减模型）：

```yaml
      loomy:
        apiKeyEnv: LOOMY_PROXY_API_KEY     # 反代不校验 key，随便填
        api: openai-completions
        baseURL: http://127.0.0.1:8790/v1
        defaultInput:
          - text
          - image
        models:
          - id: deepseek-v4.1-flash        # 反代提供的别名，大小写不敏感
            name: loomy/deepseek-v4.1-flash
            contextWindow: 1048576
            maxTokens: 128000
            input: [text, image]
            reasoningEfforts:
              off: null
              low: low
              medium: medium
              high: high
              max: xhigh
            compat:
              supportsDeveloperRole: false
```

再在 `C:\Users\<你>\.dsh\.credentials.yaml` 的 `refs` 里加一行（反代不校验 API key，占位即可）：

```yaml
    LOOMY_PROXY_API_KEY: local-no-auth
```

**改完必须重启 DSH 桌面应用**（配置在启动时加载，不重启不生效）。重启后模型选择器里会出现 `loomy/…` 前缀的模型；选它就走本反代。用之前确保 `start-loomy-proxy.cmd` 已在运行。

### 3.2 curl 示例

```powershell
# 模型列表（返回上游实时模型清单 + 小写别名；条数随上游变动，以实时返回为准）
curl.exe -s http://127.0.0.1:8790/v1/models

# 非流式对话
curl.exe -s http://127.0.0.1:8790/v1/chat/completions `
  -H "Content-Type: application/json" `
  -d "{\"model\":\"deepseek-v4.1-flash\",\"messages\":[{\"role\":\"user\",\"content\":\"你好\"}]}"

# 流式（SSE，逐块输出，最后 [DONE]）
curl.exe -N http://127.0.0.1:8790/v1/chat/completions `
  -H "Content-Type: application/json" `
  -d "{\"model\":\"deepseek-v4.1-flash\",\"messages\":[{\"role\":\"user\",\"content\":\"数到五\"}],\"stream\":true}"

# function calling（tools）
curl.exe -s http://127.0.0.1:8790/v1/chat/completions `
  -H "Content-Type: application/json" `
  -d "{\"model\":\"deepseek-v4.1-flash\",\"messages\":[{\"role\":\"user\",\"content\":\"北京现在天气如何？\"}],\"tools\":[{\"type\":\"function\",\"function\":{\"name\":\"get_weather\",\"description\":\"查询天气\",\"parameters\":{\"type\":\"object\",\"properties\":{\"city\":{\"type\":\"string\"}},\"required\":[\"city\"]}}}]}"
```

要点：

- `Authorization` 头**不需要**（反代不校验客户端 key），带了也不影响；
- 模型名大小写不敏感：`deepseek-v4.1-flash` 会自动映射到上游的 `DeepSeek-V4.1-Flash`；
- 响应里 `usage.points_consumed` 是本次消耗的积分（V4.1 Flash 实测每次 1 点）；
- 未知模型返回 `400`；池里没有可用账号时返回 `502/503`，错误体里会提示去哪个端口登录。

**写此包时实测的模型清单**（上游会变动，以你的 `/v1/models` 实时返回为准）：上游 12 个 —— `DeepSeek-V4.1-Flash`（x2.0）、`deepseek-v4-flash-0731`（x3.0）、`MiniMax-M3`（x4.0）、`Kimi-k2.6`（x6.5）、`qwen-3.8-max`（x12.0）、`GLM-5.3-Flash`（x0.8）、`qwen3.8-flash`（x0.8）、`spark-x`（限时免费 x0.0）、`mimo-v2.5`（x3.3）、`Hy-Image-3.5-preview`、`qwen-image-3.0-pro`、`doubao-seedream-5-lite`，外加若干小写别名，**总数在上游调整后会变（实测 17~18 条）**。每次对话按倍率消耗账号积分（响应里的 `usage.points_consumed`）。

> 其中 `*-image-*` / `*-seedream-*` 是图像类模型，走 `/v1/chat/completions` 未必是纯文本返回，客户端要自己处理（DSH 里默认没挂这几个）。

### 3.3 额度快照

```powershell
curl.exe -s http://127.0.0.1:8790/credit                 # 每个账号的额度/健康/状态
curl.exe -s "http://127.0.0.1:8790/credit?refresh=1"     # 立即向上游刷新（上游慢，最坏等近 1 分钟）
```

选号只读缓存，不会因为刷新而阻塞对话；上游 `GET /points/records` 实测延迟 1s~53s 抖动，反代对这个慢接口加了超时与保护。

### 3.4 管理面板

浏览器打开 `http://127.0.0.1:8790/admin`（5 秒自动刷新）：账号表、额度、启用/禁用、手动刷新。

面板与读接口是只读/免鉴权的；**写操作**（禁用账号、强制刷新）必须显式配置 `ADMIN_TOKEN`，否则一律 `403`：

```powershell
$env:ADMIN_TOKEN='my-token'
node loomy-proxy.mjs

curl.exe -s -X POST http://127.0.0.1:8790/admin/api/accounts/<账号id>/enabled `
  -H "x-admin-token: my-token" -H "content-type: application/json" -d "{\"enabled\":false}"
```

JSON 接口：`GET /admin/api/accounts`（同 `/credit`），`POST /admin/api/refresh`，`POST /admin/api/accounts/:id/enabled`。

v2.1.0 起面板底部多了「今日签到」卡片，并配套两个接口：

```powershell
curl.exe -s http://127.0.0.1:8790/admin/api/daily          # 读每日任务状态（脱敏、匿名可读）
curl.exe -s -X POST http://127.0.0.1:8790/admin/api/daily/run `
  -H "x-admin-token: my-token" -H "content-type: application/json" `
  -d "{\"apply\":false}"                                    # 触发一次检查；\"apply\":true 才领取
```

`/health` 里也会带 `daily_tasks: { last_run_at, last_mode, running }`。

### 3.5 每日任务 / 签到

**默认只读检查**，什么都不改：

```powershell
.\start-loomy-daily.cmd                    # 一键（脚本存在时）
node daily-tasks.mjs                       # 等价
node daily-tasks.mjs --json                # 机器可读输出（供面板/脚本消费）
node daily-tasks.mjs --raw                 # 附带上游原始响应
node daily-tasks.mjs --account=<id|手机号|userid>   # 只查某个账号
node daily-tasks.mjs --help
```

> 注意参数是 `--account=<值>` 的等号形式（脚本只解析 `--key=value`），写成空格分隔的 `--account <值>` 会被忽略。

它拉取并汇总：新手任务完成度（`GET /onboarding/tasks`）、今日打工奖励（`GET /pet-work`）、积分余额与今日额度（`GET /points/records`）、激活状态（`GET /points/activation`），写入 `daily-tasks-state.json`（脱敏快照，供 `/admin` 面板的「今日签到」卡片读取）并追加 `logs/daily-tasks.log`。账号来源与反代完全一致（桌面 `auth-session.json`、`web-session.json`、`accounts/*.json`、`LOOMY_SESSION_FILES`，同 userid 去重）。

**加 `--apply` 才会执行写操作**，且都是幂等的：

```powershell
node daily-tasks.mjs --apply
```

- 未完成的新手任务逐条 `POST /onboarding/tasks/complete {key}`；
- `POST /points/first-login`（首次登录奖励，幂等）；
- **打工奖励只在本地能找到客户端真实活动数据、且能据此复算档位时才领取**；本地没有数据就只报告、不领取。脚本**不会**凭空构造 `reachedTierId` 去骗取奖励——这是硬性设计边界。

想每天自动跑一次，可以用附带的计划任务脚本（可选，需要 PowerShell 7）：

```powershell
pwsh -File .\install-daily-task.ps1               # 注册/更新：每天 09:05 只读检查
pwsh -File .\install-daily-task.ps1 -Apply        # 每天 09:05 检查并领取可合法领取的奖励
pwsh -File .\install-daily-task.ps1 -Time 08:30 -Apply
pwsh -File .\install-daily-task.ps1 -Remove       # 删除计划任务
```

它只调用本目录的 `start-loomy-daily.cmd`，不下载任何东西；注册失败（需要管理员权限时）按提示用「任务计划程序」手动创建同样即可。

### 3.6 池参数（环境变量，都有默认值）

| 变量 | 默认 | 含义 |
| --- | --- | --- |
| `PORT` / `LOOMY_PROXY_PORT` | `8790` | 反代端口 |
| `LOOMY_UPSTREAM` | `https://loomyad.xunfei.cn/api/v1` | 上游基址 |
| `LOOMY_PUBLIC` | `C:\Users\Public\Loomy` | 桌面授权文件扫描根目录 |
| `LOOMY_ACCOUNTS_DIR` | `./accounts` | 手动账号目录 |
| `LOOMY_SESSION_FILES` | 空 | 额外 session 文件（`;` 分隔） |
| `POOL_MAX_IN_FLIGHT` | `3` | 单账号并发上限 |
| `POOL_BREAKER_THRESHOLD` / `POOL_BREAKER_COOLDOWN` | `3` / `1800` | 连续失败几次熔断 / 熔断秒数（翻倍至 `POOL_BREAKER_COOLDOWN_MAX=21600`） |
| `POOL_SOFT_RATE_COOLDOWN` / `_MAX` | `600` / `7200` | 429 软冷却起点 / 上限（秒） |
| `POOL_FAILOVER_ATTEMPTS` / `POOL_FAILOVER_DEADLINE` | `3` / `20` | 请求级最多重试次数 / 总时限（秒） |
| `CREDIT_REFRESH_INTERVAL` | `300` | 额度缓存有效期（秒） |
| `ADMIN_TOKEN` | 未设 | 管理写操作的 token；未设则写操作 403 |
| `LOOMY_DAILY_TIMEOUT` / `LOOMY_DAILY_SLOW_TIMEOUT` | `60` / `120` | `daily-tasks.mjs` 普通接口 / 慢接口超时（秒） |
| `LOOMY_DAILY_STATE` | `./daily-tasks-state.json` | 每日任务状态文件位置 |

---

## 四、目录结构

压缩包解压后：

```
loomy-proxy-v2.1.2/
├─ README.md                  # 本文件（自包含说明）
├─ README.detailed.md         # 开发过程的详细备忘（实测数据、版本修复记录、逆向笔记）
├─ loomy-proxy.mjs            # 反代主体 v2.1.0（零依赖，Node 22+）
├─ web-auth.mjs               # 网页登录服务（127.0.0.1:8791）
├─ daily-tasks.mjs            # 每日任务 / 签到 CLI
├─ launch-detached.mjs        # 后台启动器：detached 进程 + 文件日志（关窗口不影响）
├─ start-all.cmd              # 一键启动：反代 8790 + 网页登录 8791（幂等）
├─ stop-all.cmd               # 停止两个服务
├─ start-loomy-proxy.cmd      # 只启动反代（后台）
├─ start-loomy-login.cmd      # 启动网页登录（后台）并打开浏览器
├─ start-loomy-daily.cmd      # 一键跑每日任务
├─ install-daily-task.ps1     # 可选：注册「每天自动签到」计划任务（pwsh 7）
├─ lib/
│  └─ xfyun-account.mjs       # 讯飞账号登录库：解出客户端凭据、HMAC-SHA1 签名、短信登录、网关校验
└─ legacy/
   ├─ loomy-proxy.v1.mjs      # 旧版单账号反代（回滚用）
   └─ web-login.mjs           # 旧版走网页 cookie 的登录脚本（已证实打不通网关，仅留档）
```

**压缩包里刻意没有**（也因此不会有你的凭据外泄）：`secrets/`（客户端凭据）、`*.session.json`（就是你自己的登录态）、`accounts/`、`daily-tasks-state.json`、`logs/`、`recon/`（逆向产物）、`node_modules/`、`.git/`、`dist-zip/`。运行后这些文件会在你本地生成。

### 运行期会自动生成

| 路径 | 说明 |
| --- | --- |
| `web-session.json` | 网页登录得到的 session（`kind: "gateway-session"`），等同于登录态，别外传 |
| `daily-tasks-state.json` | 每日任务的脱敏快照（面板读取） |
| `logs/` | 反代 / 网页登录 / 每日任务的运行日志：`proxy.log`、`proxy.err.log`、`web-auth.log`、`web-auth.err.log`、`daily-tasks-run.log`（已对 session 脱敏；只追加不轮转） |
| `accounts/` | 你手动放置的额外账号 |

---

## 五、常见问题

**Q：对话返回 `{"error":{"message":"没有可用账号：请在 Loomy 客户端登录，或访问 http://127.0.0.1:8791 用网页登录"}}`**
账号池空了。按第二节方式 A/B/C 补一个 session，15 秒内自动发现；或看 `/credit` 确认账号是不是被标成 `needs_relogin`。

**Q：`Loomy is not logged in` / 上游返回 `{"code":"100002","desc":"登录已失效"}`**
session 失效（被踢下线、换设备、太久没用）。重新走一次网页登录，或在客户端重新登录一次；反代会自动取最新的那个。

**Q：模型返回 400 / `model not found`**
模型 id 必须是 `/v1/models` 里真实存在的（上游模型 + 其小写别名，两者都能用）。别自己编 id；大小写不敏感，但拼写要对。

**Q：额度不足 / 429 限流**
看 `curl.exe -s http://127.0.0.1:8790/credit`。429 会让该账号软冷却 600 秒起翻倍（上限 7200 秒），期间自动换号；池里所有账号都不可用时返回 502/503。

**Q：某个模型当天第一次调用特别慢（40~60 秒）**
上游冷启动特性（实测 `qwen-3.8-max` 首次 57.8s，之后 3~6s）。若这次恰好撞上上游 5xx/断连，默认 `POOL_FAILOVER_DEADLINE=20` 秒会让它放弃重试直接 502——隔几秒重发即可成功，或调大 `POOL_FAILOVER_DEADLINE` / `POOL_FAILOVER_ATTEMPTS`。

**Q：网页登录页报 `未找到 Loomy 环境文件（.env.prod）`**
见第二节「方式 A」的说明：装过 Loomy 客户端的话脚本会自动找到；否则把客户端的 `resources\.env.prod` 放进 `secrets\.env.prod`，或设 `LOOMY_ENV_PATH`。

补充：这个文件是**启动阶段**就要读的。如果 `logs\web-auth.log` 里是「启动失败：未找到 Loomy 环境文件（.env.prod）」，说明 8791 根本没起来（反代 8790 不受影响，仍可用已有 session 对话）。补齐 `.env.prod` 后重新 `start-all.cmd` 即可。

**Q：端口被占用 / 想换端口**
`node loomy-proxy.mjs --port=8890`，或设 `$env:PORT=8890`。网页登录同理：`node web-auth.mjs --port=8792`。

**Q：能被局域网/公网访问吗？**
不能，也不建议。三个服务都硬编码只监听 `127.0.0.1`，只在本机可用。

**Q：日志/面板会泄露我的 session 吗？**
不会。`/health`、`/credit`、`/admin` 与运行日志只输出打码 session（前 6 后 4），日志不打印 token。你自己别把 `web-session.json` / `auth-session.json` 发出去就行。

**Q：关掉启动窗口，服务是不是就没了？怎么停？日志在哪？**
v2.1.2 起不会。两个服务由 `launch-detached.mjs` 以 detached 进程启动，关窗口/关终端都不影响；日志固定写在 `logs\proxy.log` 与 `logs\web-auth.log`。要停用 `stop-all.cmd`。v2.1.1 及更早的 `start-all.cmd` 是在控制台窗口里起服务，关窗口会把两个服务一起杀掉（日志也只留在那个窗口里）。

**Q：日志里出现「额度刷新失败 … 系统内部错误」要紧吗？**
不要紧。这是上游 `/points/records` 的瞬态错误（和它 1s~53s 的延迟波动同源），反代只记一行、账号继续可用（额度未知时权重降到 0.5），300 秒后的下一轮自动重试；看 `/credit` 的 `state` 恢复 `ok` 就行。

**Q：想回滚到旧版单账号反代？**
停掉 8790 的进程，执行 `node legacy\loomy-proxy.v1.mjs --port=8790`。

---

## 六、致谢

- **[wangliangdong/loomy2api](https://github.com/wangliangdong/loomy2api)** —— 本项目的账号池与额度调度思路（多账号轮询、额度份额参与权重、故障分类）参照了它。两者关键差异：本项目走**网关直连**（因此支持 `DeepSeek-V4.1-Flash`、工具调用与视觉），而参照项目走官方网页 cookie 会话（自述不支持工具调用）。
- **DeepSeek Harness** —— 本项目的主要消费方与联调环境；反代的 OpenAI 兼容行为、流式与 tools 路径都是对着它调通的。
- **Loomy 桌面客户端 / 讯飞账号开放接口** —— 上游网关与登录协议无公开文档，本项目通过对客户端自身的协议行为做分析来复刻登录签名与鉴权方式。
- 以上致谢**仅表示技术参考与来源，不代表任何官方关联、授权或背书**。

---

## 七、免责声明

1. 本项目**仅供个人学习、研究与自用接入**，不提供任何形式的商业服务。
2. 本项目**不含任何绕过付费、破解、盗用他人额度或批量注册的机制**。鉴权与额度完全来自使用者**自己账号的合法授权**（客户端登录态，或你自己手机号的短信验证码登录）。
3. **禁止**用于对外提供服务、批量注册账号、转售额度，或任何违反 Loomy / 讯飞服务条款与当地法律法规的用途。
4. **不保证可用性与持续性**：上游接口为未公开文档的内部网关，可能随时变更、限流或下线；本项目不承诺任何 SLA，也不对因使用造成的账号封禁、额度损失或数据丢失负责。
5. **使用风险自负**。请自行评估对账号状态的影响，并遵守 Loomy / 讯飞的服务条款与当地法律。
6. 本项目与 **Loomy、讯飞官方没有任何关联，未获其授权或认可**。文中出现的产品名、商标归各自所有者所有。
7. 请勿公开分享你的反代地址、`auth-session.json`、`web-session.json` 或 `secrets/` 中的任何内容——它们等同于你的账号登录态。
