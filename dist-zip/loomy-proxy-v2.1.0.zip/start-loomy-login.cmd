@echo off
rem Start Loomy web-login auth service (no desktop client needed)
rem Opens http://127.0.0.1:8791 ; login with phone + SMS code -> writes web-session.json
setlocal
set "PORT=8791"
curl.exe -s -m 2 "http://127.0.0.1:%PORT%/health" >nul 2>&1
if not errorlevel 1 (
  echo [loomy-web-auth] already running, opening browser...
  start "" "http://127.0.0.1:%PORT%"
  exit /b 0
)
set "NODE=%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe"
if not exist "%NODE%" set "NODE=node"
cd /d "%~dp0"
start "loomy-web-auth" "%NODE%" "%~dp0web-auth.mjs" --port=%PORT%
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:%PORT%"
echo [loomy-web-auth] started: http://127.0.0.1:%PORT%
