# 龙虾反代 · Loomy 授权态 → OpenAI 兼容层

把 **Loomy（讯飞）桌面客户端的登录授权** 变成标准 OpenAI 协议接口，从而让 DeepSeek Harness（以及任何 OpenAI 兼容客户端）在请求头正确的前提下调用 **DeepSeek-V4.1-Flash**。

创建时间：2026-10-19 · 实测环境：Windows + Loomy 0.9.39

---

## 一、结论（已实测）

| 项目 | 结果 |
| --- | --- |
| 授权文件获取 | ✅ `C:\Users\Public\Loomy\<用户hash>\userData\auth-session.json`（客户端登录后写入） |
| 网页登录授权 | ✅ `http://127.0.0.1:8791` 手机号 + 短信验证码，复刻客户端登录协议，直接换到**同源 session**（无需安装/启动 Loomy），落到 `web-session.json` |
| 上游网关 | ✅ `https://loomyad.xunfei.cn/api/v1`（OpenAI 兼容） |
| 鉴权头（关键） | ✅ `GET /models` 用 `token: <session>`；`POST /chat/completions` 用 `Authorization: Bearer <session>` |
| DeepSeek-V4.1-Flash | ✅ 存在，模型 id **`DeepSeek-V4.1-Flash`**（1,048,576 上下文 / 384,000 最大输出，支持推理、视觉、函数调用、流式） |
| 实际对话 | ✅ 非流式 / 流式均通过（含 system、reasoning_effort、tools 函数调用） |
| 本地反代 | ✅ `loomy-proxy.mjs` **v2.0.3** @ `127.0.0.1:8790`：多账号池 + 额度感知选号 + 熔断/故障转移 + 模型别名 + `/credit` + `/admin` |
| DSH 接入 | ✅ 已重启生效：模型选择器里的 `loomy/deepseek-v4.1-flash`（本会话即走这条链路） |

> 注：登录本身仍是讯飞账号授权（手机短信验证码 / 微信扫码）——由 dj 在 Loomy 客户端完成，授权状态落盘为 `auth-session.json`；本方案是「复用该授权文件」，不是绕过账号验证。

---

## 二、授权文件与两个鉴权头

```
C:\Users\Public\Loomy\<sha256(用户名)前12位>\userData\auth-session.json
{
  "session": "<32 位 hex，即上游 token>",
  "userid": "<你的 userid>",
  "phone": "138****0000",
  "updatedAt": 1792399763043
}
```

实测（同一 session）：

| 请求 | 使用的头 | 结果 |
| --- | --- | --- |
| `GET /api/v1/models` | `token: <session>` | ✅ 200，返回模型清单 |
| `GET /api/v1/models` | `Authorization: Bearer <session>` | ❌ `{"code":"100002","desc":"缺少 token"}` |
| `POST /api/v1/chat/completions` | `token: <session>` | ❌ `缺少 token` |
| `POST /api/v1/chat/completions` | `Authorization: Bearer <session>` | ✅ 200 正常补全 |
| `POST /api/v1/chat/completions` | 两个头都带 | ✅ 正常（推荐） |

即：**列表接口认 `token` 头，补全接口认 `Bearer` 头**，两者不通用。v2 反代对每个上游请求**同时带上两个头**（实测两者并存正常），因此无需按路径区分。

---

## 三、可用模型（网关实时返回，节选）

| id | 名称 | 倍率 |
| --- | --- | --- |
| `DeepSeek-V4.1-Flash` | DeepSeek V4.1 Flash | x2.0 |
| `deepseek-v4-flash-0731` | DeepSeek V4 Flash 0731 | x3.0 |
| `MiniMax-M3` | MiniMax M3 | x4.0 |
| `Kimi-k2.6` | Kimi k2.6 | x6.5 |
| `qwen-3.8-max` | Qwen 3.8 Max | x12.0 |
| `GLM-5.3-Flash` | GLM 5.3 Flash | x0.8 |
| `qwen3.8-flash` | qwen 3.8 flash | x0.8 |
| `spark-x` | Spark-X2.5（限时免费） | x0.0 |
| `mimo-v2.5` | MiMo V2.5 | x3.3 |
| `auto` | 自动 · 均衡 | — |

> 每次对话按倍率消耗账号积分（响应里 `usage.points_consumed`，V4.1 Flash 实测每次 1 点）。

---

## 四、启动与使用

```powershell
# 启动反代（隐藏窗口，后台常驻）
.\start-loomy-proxy.cmd

# 健康检查：应返回授权文件路径与 userid
curl.exe -s http://127.0.0.1:8790/health

# 模型列表
curl.exe -s http://127.0.0.1:8790/v1/models

# 对话（支持 stream=true；模型名大小写不敏感，"deepseek-v4.1-flash" 会自动映射到上游 "DeepSeek-V4.1-Flash"）
curl.exe -s http://127.0.0.1:8790/v1/chat/completions `
  -H "Content-Type: application/json" `
  -d '{\"model\":\"deepseek-v4.1-flash\",\"messages\":[{\"role\":\"user\",\"content\":\"你好\"}],\"stream\":false}'
```

- session 每次请求实时读取，客户端重新登录后立即生效；
- 授权失效时上游返回 `登录已失效，请重新登录`，反代原样透传；
- 仅监听 `127.0.0.1`，不对外暴露；如需换端口 `node loomy-proxy.mjs --port=8791`。

---

## 五、反代 v2：账号池 · 额度 · 管理面板

**v2.0.3**（2026-10-19）在 v1「单授权文件」的基础上移植了参照项目 [loomy2api](https://github.com/wangliangdong/loomy2api) 的调度能力；关键差异是 **v2 走网关直连**（因此支持 V4.1 Flash、工具调用、视觉），而参照项目走网页 cookie（README 自述不支持工具调用，模型表里也没有 V4.1 Flash）。

> 账号文件安全性：除桌面 `auth-session.json` 外，只有**带 `kind: "gateway-session"` 标记**的 `web-session.json` 会被采纳（v2.0.2 起严格要求）。官方网页 cookie 会话打网关必然 `100002 登录已失效`，旧脚本 `legacy/web-login.mjs` 会把它写进同一个文件，所以必须靠这个标记挡住。

| 能力 | 说明 |
| --- | --- |
| 多账号池 | 自动发现 `C:\Users\Public\Loomy\*\userData\auth-session.json`（桌面）、`web-session.json`（网页登录）、`accounts/*.json`（手动放置）以及 `LOOMY_SESSION_FILES`；每 15s 重扫，同一账号的多个 session 都作为候选 |
| 选号 | 平滑加权轮询（SWRR）：权重 = 额度份额 × 健康度 × 空闲度 ÷ (1+并发)，避免突发与偏袒 |
| 故障转移 | 请求级最多重试 3 次 / 20s；只在**首字节之前**转移，流式已开始就不再重试 |
| 故障分类 | 鉴权失效（401/403/`100002`/`登录已失效`）→ 标记 `needs_relogin` 并移出调度；429/限流 → 软冷却 600s 起翻倍（上限 7200s）；5xx/408/409/425 → 连续 3 次熔断 1800s 起翻倍（上限 21600s）；客户端 4xx 原样返回 |
| 额度感知 | 读 `GET /points/records`（上游实测 1s~53s 波动），每 30s 增量 tick：只刷「缓存超过 300s」且「当前空闲」的账号，忙的下个 tick 再补（v2.0.0 的"忙就跳过整个周期"会把常用账号饿死，已在 v2.0.1 修掉）；选号只读缓存，不阻塞请求 |
| 管理面板 | `http://127.0.0.1:8790/admin`（5s 自动刷新）；JSON：`/credit`、`/admin/api/accounts` |
| 脱敏 | `/health`、`/credit`、`/admin`、运行日志一律只输出打码 session，日志不打印 token |

**有意不照搬的一点**：不做会话粘性。上游是 OpenAI 兼容的**无状态**网关（每次带完整 `messages`，没有服务端会话 ID），跨账号轮询不会丢上下文，粘性在这里没有意义。

**版本修复记录**（每条都先复现、后修，并由独立验证者复核）：

| 版本 | 修了什么 |
| --- | --- |
| v2.0.1 | 额度刷新改为 30s 增量 tick。v2.0.0「忙就跳过整个周期」会饿死一直在用的账号，`/credit` 永远停在旧值 |
| v2.0.2 | `web-session.json` 必须带 `kind: "gateway-session"` 才被采纳。旧脚本写的官方网页 cookie 会话打网关必然 `100002`，会毒化整个池子 |
| v2.0.3 | ① **非流式鉴权误判（高）**：上游失败时返回的是 `HTTP 200 + {"code":"100002"}`，此前被当成成功透传给客户端，坏账号还能拿到 `ok+1`、永不标 `needs_relogin`；现在非流式路径同样检查响应体，坏账号立即移出调度并换号重试。② **流式额度重复计数（中）**：`points_consumed` 会在 SSE 里出现两次，此前按 TCP 分块累计，一次请求可能记 `+2`；现在每个响应只累计一次。③ **运行期驱逐（中）**：已被采纳账号的 session 被替换后，下一轮重扫（15s）标记 `needs_relogin`（原因「授权文件中的会话已被替换」），此前只在文件消失时才清理。④ **管理面脏请求（低）**：`/admin/api/accounts/:id/enabled` 的 body 超 4 KiB 或非法 JSON 时返回 `413/400`，此前 `readBody` 的 reject 被吞掉、被当成 `enabled:false` **静默禁用账号**。另：额度未知的账号权重由 1 降为 0.5（不再比健康账号更容易被选中），`/health` 在全部账号失效时 `auth_file` 返回 `null` |

**独立验证记录**（验证者另起实例、只读被测文件、只用 8794 端口，不碰正式实例）：

| 轮次 | 被测版本 | 报告 | 结论 |
| --- | --- | --- | --- |
| 第一轮 | v2.0.2 | `recon/verify-notes.md` | 10 项检查 8 通过 2 失败，报出 F1–F4 四个缺陷（即上表 v2.0.3 行） |
| 第二轮 | v2.0.3（size 37481 B，sha256 `405715F8678CE94308EF620E2DFB42A4A93C502C41FC36C470C99367C3EF0607`） | `recon/verify-notes-round2.md` | F1–F4 **四项全部通过**；回归面通过：18 条模型 + 5 个别名、SSE 增量与 `[DONE]`、未知模型 400、70 MB 请求体 413（顺手修掉旧版的 ECONNRESET）、95 个文件脱敏 **0** 泄漏、收尾无残留监听 |
| 第三轮 | v2.1.0（`loomy-proxy.mjs` size 46586 B，sha256 `8c45b9f540c3e3dafaba1e45443f3da3a13b76e042500e766353a4241fc16d4a`；`daily-tasks.mjs` 被测版本 v1.0.0 size 23140 B，sha256 `7cd4d7a0a2200d209bef08c0f39cb5d39e275aeaa2021f5958a2163b10995296`） | `recon/verify-notes-round3.md`（独立验证者，5/5 通过）+ `recon/lead-accept-v210.ps1`（Lead 自测，25/25 通过） | 集成面全通过：`/health` 版本与 `daily_tasks`、`/admin/api/daily` 匿名只读、`run` 无令牌 403 / 带令牌 202 / 运行中再发 409 且只起一个子进程、畸形 body 400、超 4 KiB 413、子进程 `exit_code=0` 且 `logs/daily-tasks-run.log` 落地、`/admin` 有「今日签到」卡片且 HTML 与 JSON 端点均无 32 位 hex 泄漏、回归面 18 条模型 + 小写别名 + 未知模型 400 + 非流式对话正常；另确认只读模式 4 个请求全为 GET（上游桩逐请求留痕）、诚实边界成立。独立验证另报 **N1（低）**：写状态文件时漏了 `skipped` 字段，`loomy-proxy.mjs` 读 `a.skipped` 恒为空，面板「为什么没领打工奖励」永远不显示原因 —— 已修（`daily-tasks.mjs` v1.0.1：透传 `skipped`，同时修 `--account=` 不匹配时误报「没有找到任何 Loomy 会话」，size 23492 B，sha256 `d8c886fdcfca6773129eff81ab02c0bfd9a0896b193275932395dc7d1838f850`；两处都是验证后修改，已 `node --check` + 只读实测复跑） |

**已知小问题（不影响使用，本轮未改）**：

1. 账号被驱逐时只体现在 `/credit` 的字段变化上，日志没有对应行——排查时看 `/admin` 面板更直观。
2. 流式 `points_consumed` 的关键字与数字若被拆到相邻 TCP 分块、且累计缓冲超过 8 KiB 上限，理论上可能漏记一次额度（两轮验证都未复现）。
3. 池里只剩失效账号时，`/v1/models` 会退回 13 条静态清单（健康实例通常 18 条；上游本身在 17↔18 间浮动，以实时返回为准）；对话本身不受影响（此时返回 502/503）。
4. 上游 `/points/records` 会偶发瞬态 `{"code":"100002","desc":"登录已失效"}`（同一 session 连打 4 次全部 `000000`），`daily-tasks.mjs` 把它记进 `errors`、不自动重试；重跑一次即可，不要据此判断账号失效。
5. `POST /admin/api/daily/run` 之外的 HTTP 方法打到该路径返回 404（不是 405），脚本缺失时返回 409 而不是 5xx —— 语义不够严格，不影响功能。

```powershell
curl.exe -s http://127.0.0.1:8790/health                # 账号数 / 上游 / 额度
curl.exe -s http://127.0.0.1:8790/credit                # 完整额度与健康快照
curl.exe -s "http://127.0.0.1:8790/credit?refresh=1"    # 立即刷新（上游慢，最坏 1 分钟）
start http://127.0.0.1:8790/admin                       # 面板
```

池参数（环境变量，都有默认值）：`POOL_MAX_IN_FLIGHT=3`、`POOL_BREAKER_THRESHOLD=3`、`POOL_BREAKER_COOLDOWN=1800`、`POOL_SOFT_RATE_COOLDOWN=600`、`POOL_SOFT_RATE_COOLDOWN_MAX=7200`、`POOL_FAILOVER_ATTEMPTS=3`、`POOL_FAILOVER_DEADLINE=20`（秒）、`CREDIT_REFRESH_INTERVAL=300`（秒）、`ADMIN_TOKEN`。

管理写操作（启用/禁用账号、强制刷新）在未配置 `ADMIN_TOKEN` 时**一律 403**：

```powershell
$env:ADMIN_TOKEN='my-token'; node loomy-proxy.mjs
curl.exe -s -X POST http://127.0.0.1:8790/admin/api/accounts/<id>/enabled `
  -H "x-admin-token: my-token" -H "content-type: application/json" -d "{\"enabled\":false}"
```

**回滚到 v1**：旧版单账号实现归档在 `legacy/loomy-proxy.v1.mjs`。停掉 8790 的进程后执行 `node legacy\loomy-proxy.v1.mjs --port=8790` 即可（v1 只取 mtime 最新的一个授权文件，其余行为与 v2 单账号时一致）。

---

## 六、网页登录（无需桌面客户端）

```powershell
.\start-loomy-login.cmd          # 启动服务并自动打开浏览器
# 或手动：node web-auth.mjs      → http://127.0.0.1:8791
```

页面流程：手机号 → 「发送验证码」→ 填 6 位码 → 「登录并获取 token」。成功后页面显示打码 session、userid 与**网关校验结果**，并写入：

```json
// web-session.json
{
  "kind": "gateway-session",          // 反代只认这个标记，避免误用官方网页 cookie 会话
  "session": "<32 位 hex，与桌面端 auth-session.json 的 session 同源>",
  "phone": "138****0000",
  "userid": "<你的 userid>",
  "source": "xfyun-sms-web",
  "updatedAt": 1792401056724,
  "gateway": { "ok": true, "modelCount": 12 }
}
```

实现原理：

- 桌面端登录 = **讯飞账号 API**（`https://account.xfinfr.com`，HMAC-SHA1 签名，头 `Authorization: account <akid>:<sig>`）→ 返回的 `session` 就是网关认可的 token；本项目从客户端 `.env.prod`（AES-256-GCM + scrypt）解出同一套 appid/AK，在 `lib/xfyun-account.mjs` 复刻签名，调用 `/login/phone/sendMsgCode` 与 `/login/phone/checkCode`，拿到与客户端**完全相同**的 session。
- v2 反代把它当作**账号池里的一个候选**（与桌面授权文件、`accounts/*.json` 一起参与调度），因此网页登录后**无需重启反代**；桌面端重登、网页重登都会在 15s 内被发现。
- 官方 `loomy.xunfei.cn` 网页的 cookie 会话**不能**用于网关（实测 `token: <cookie会话>` → `{"code":"100002","desc":"登录已失效"}`）。本方案是复刻客户端登录协议，不是抓网页 cookie。

实测（2026-10-19，网页登录得到的 session）：`/v1/models` 返回 18 条（12 个上游模型 + 小写别名），`deepseek-v4.1-flash` 非流式对话 21s 返回正常内容，`usage.points_consumed = 1`。

> ⚠️ 上游 `/models` 在**登录态有效时直接返回裸数组**，失效时才返回 `{code,desc}` 对象。判断鉴权不要只找 `code === "000000"`（本项目踩过这个坑，页面显示"网关校验未通过"其实 session 是好的）。

---

## 七、DeepSeek Harness 接入

已修改（均有备份）：

| 文件 | 改动 | 备份 |
| --- | --- | --- |
| `%USERPROFILE%\.dsh\profiles\desktop\cordis.patch.yml` | 在 `llm-pi-ai.providers` 下新增 `loomy` 提供方，基址 `http://127.0.0.1:8790/v1`；已挂 **9 个模型**（括号内为上下文/单次输出上限）：`deepseek-v4.1-flash`（1M/128k，上游真名 `DeepSeek-V4.1-Flash`，`deepseek-v4.1-flash` 是反代提供的别名）、`deepseek-v4-flash-0731`（1M/128k）、`GLM-5.3-Flash`（1M/64k）、`qwen3.8-flash`（1M/64k）、`qwen-3.8-max`（1M/32k）、`MiniMax-M3`（1M/128k）、`Kimi-k2.6`（256k/32k）、`mimo-v2.5`（1M）、`spark-x`（1M） | 首次只加 1 个模型时的备份 `cordis.patch.yml.bak-20261019-loomy`；扩到 9 个模型前的备份 `cordis.patch.yml.bak-20261019-loomy-v2` |
| `%USERPROFILE%\.dsh\.credentials.yaml` | refs 增加 `LOOMY_PROXY_API_KEY: local-no-auth`（反代不校验 key） | `.credentials.yaml.bak-20261019-loomy` |

生效方式：**重启 DSH 桌面应用**（配置在启动时加载）。重启后在模型选择器即可看到 `loomy/` 前缀的 9 个模型；选它即通过本反代走 Loomy 授权调用。使用前请确保反代在运行。

回滚：用上表备份覆盖回去并重启即可。

---

## 八、每日任务与签到（daily-tasks.mjs）

Loomy 网关有一套官方的积分任务接口，`daily-tasks.mjs` 把它们做成可审计的签到脚本（**默认只读**，加 `--apply` 才写）：

| 用途 | 接口 | 要点 |
| --- | --- | --- |
| 新手任务完成度 | `GET /api/v1/onboarding/tasks` | 返回 8 个任务的布尔表 + `earned/total`（满额 10000 分） |
| 领取新手任务 | `POST /api/v1/onboarding/tasks/complete {key}` | 幂等，响应带 `alreadyCompleted` |
| 今日打工奖励 | `GET /api/v1/pet-work` | `config`（档位/权重/基线）+ `status`（今日已得、已领档位、是否封顶） |
| 领取打工奖励 | `POST /api/v1/pet-work/rewards` | 入参 `{businessDate, configVersion, reachedTierId}`，档位由活动量复算 |
| 首次登录奖励 | `POST /api/v1/points/first-login` | 幂等 |
| 余额 / 流水 | `GET /api/v1/points/records` | `balance` / `dailyBalance` / `availableBalance` |
| 激活状态 | `GET /api/v1/points/activation` | — |

```bat
start-loomy-daily.cmd                       :: 只读检查：新手任务 + 今日打工 + 余额
start-loomy-daily.cmd --apply               :: 领取可合法领取的奖励
node daily-tasks.mjs --json                 :: 机器可读输出（供面板/脚本消费）
node daily-tasks.mjs --raw                  :: 调试：打印上游原始 JSON
pwsh -File install-daily-task.ps1 -Apply    :: 注册「每天 09:05 自动签到」的 Windows 计划任务
pwsh -File install-daily-task.ps1 -Remove   :: 删除该计划任务
```

**打工奖励的诚实边界**：档位由客户端本地的活动量（`activeSessionCount` / `extraValidTurnCount`）按官方公式复算，再对照服务端的 `rewardedTierIds` 决定是否领取；**本地找不到客户端活动记录时只报告、不领取**，不会凭空构造 `reachedTierId` 去刷奖励。

反代面板 `http://127.0.0.1:8790/admin` 底部有「今日签到」卡片：每个账号的新手任务完成度、今日打工得分、已领档位、余额与最近执行时间，并带「只读检查 / 执行签到」两个按钮（写操作需要 `ADMIN_TOKEN`，未配置时一律 403）。相关接口：`GET /admin/api/daily`（读状态，无需令牌）、`POST /admin/api/daily/run`（body `{"apply":true|false}`，需 `X-Admin-Token`）。状态落盘在 `daily-tasks-state.json`（已脱敏，不含 session），日志在 `logs/daily-tasks.log` 与 `logs/daily-tasks-run.log`。

---

## 九、文件清单

| 文件 | 说明 |
| --- | --- |
| `loomy-proxy.mjs` | 反代主体 **v2.1.0**（零依赖，Node 22+）：账号池、额度感知选号、熔断/故障转移、双鉴权头注入、流式透传、模型别名、`/credit`、`/admin` 面板（含「今日签到」卡片） |
| `accounts/`（可选） | 手动放置的额外账号 JSON（`{"session":"…","userid":"…","phone":"…"}`），自动纳入账号池 |
| `start-loomy-proxy.cmd` | 启动脚本（优先用 DSH 自带 node，回退 PATH 中的 node） |
| `web-auth.mjs` | 网页登录服务 + 登录页（`127.0.0.1:8791`），复刻讯飞账号登录换 session |
| `lib/xfyun-account.mjs` | 讯飞账号登录库：解密客户端凭据、HMAC-SHA1 签名、短信登录、网关校验 |
| `start-loomy-login.cmd` | 一键启动网页登录服务并自动打开浏览器 |
| `secrets/loomy.env.enc` | 客户端 `.env.prod` 的加密副本（等同客户端凭据，勿外传） |
| `logs/` | 反代与登录服务的运行日志 |
| `legacy/` | 历史版本，仅供对照：`loomy-proxy.v1.mjs`（单账号版反代，回滚见第五节末尾）、`web-login.mjs`（走网页 cookie 的旧登录脚本，已证实拿到的会话打不通网关） |
| `daily-tasks.mjs` | 每日任务/签到脚本：新手任务完成度、打工奖励（只按本地真实活动复算）、余额快照；默认只读，`--apply` 才写 |
| `start-loomy-daily.cmd` | 一键执行签到（不带参数=只读检查，`--apply`=领取） |
| `install-daily-task.ps1` | 注册/删除「每天自动签到」的 Windows 计划任务（可选） |
| `daily-tasks-state.json` | 签到结果快照（脱敏，供面板读取；**不要提交/分发**） |
| `PACKAGE-README.md`、`pack.ps1`、`dist-zip/` | 交付打包：自包含说明 + 打包脚本与产物（打包会排除 `secrets/`、`logs/`、`recon/`、`accounts/`、`*.session.json`、状态文件） |
| `recon/` | 逆向阶段产物（可随时删除）：客户端 `app.asar` 解包、`.env.prod` 解密、探测脚本，以及两轮独立验证报告 `verify-notes.md` / `verify-notes-round2.md` |
| `recon/models_a.json` | 网关模型清单原始响应 |
| `recon/chat_resp.json`、`recon/p1_resp.json` 等 | 实测对话原始响应 |

可选：开机自启（需管理员或当前用户计划任务）

```powershell
schtasks /create /tn "LoomyProxy" /tr "cmd /c \"D:\Download games\我爱搞科研\loomy龙虾反代\start-loomy-proxy.cmd\"" /sc onlogon /rl limited /f
```

---

## 十、注意事项

1. **不要泄露授权文件**：`auth-session.json` 等同于账号登录态；反代只读不复制。
2. 会话过期（重新登录/被踢）后需在 Loomy 客户端重登一次，反代自动跟新。
3. 上游为讯飞内网风格网关（`loomyad.xunfei.cn`），无官方文档、可能变更；接口/模型变化时以 `/v1/models` 实时返回为准。
4. 该方案依赖客户端授权与积分额度，属于个人账号自用接入，不要公开分享反代地址。
5. `secrets/loomy.env.enc` 是 Loomy 客户端凭据（appid / accessKey）的加密副本，与授权文件同等敏感，不要外传；登录服务与反代都只监听 `127.0.0.1`，不要把端口暴露到公网。
6. 网页登录得到的 session 与桌面端同源：在网页重新登录会刷新/顶掉旧的登录态，桌面客户端可能需要重新登录一次；反代始终自动取最新的那个。
7. 冷启动偏慢：某个模型**当天第一次**被调用时，上游可能要 40~60s 才出首个事件（实测 `qwen-3.8-max` 首次 57.8s，之后 3~6s；`qwen3.8-flash` 首次 45s）。若这一次恰好撞上上游 5xx/断连，反代默认的 `POOL_FAILOVER_DEADLINE=20s` 会让它放弃重试并直接回 502 —— 隔几秒重发即可成功（`POOL_FAILOVER_DEADLINE`／`POOL_FAILOVER_ATTEMPTS` 可调）。
8. `/admin` 面板的账号启停/强制刷新/签到触发都要显式配置 `ADMIN_TOKEN`，否则返回 403（`/admin`、`/health`、`/credit`、`/admin/api/daily` 只读可匿名访问）。反代与管理面都只监听 `127.0.0.1`。
9. 上游 `/points/records`（额度）延迟波动极大（实测 1s~53s），因此 `/credit?refresh=1` 可能等近一分钟；正常选号只读缓存，不影响对话延迟。签到脚本同理，慢的时候一次要跑 30~60s。
10. 签到只做**你账号本来就有的**任务与奖励：不伪造活动数据、不重复领奖、不绕过额度限制。若上游改了接口，脚本会报错而不是静默跳过——先跑只读模式看输出。
