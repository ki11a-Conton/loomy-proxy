@echo off
rem Start Loomy -> OpenAI compatible reverse proxy (loomy-proxy)
rem Listens on 127.0.0.1:8790, auto-reads Loomy auth-session.json
rem Safe to run repeatedly: exits if already running
setlocal
set "PORT=8790"
curl.exe -s -m 2 "http://127.0.0.1:%PORT%/health" >nul 2>&1
if not errorlevel 1 (
  echo [loomy-proxy] already running at http://127.0.0.1:%PORT%
  exit /b 0
)
set "NODE=%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe"
if not exist "%NODE%" set "NODE=node"
cd /d "%~dp0"
start "loomy-proxy" "%NODE%" "%~dp0loomy-proxy.mjs" --port=%PORT%
echo [loomy-proxy] started: http://127.0.0.1:%PORT%/health
