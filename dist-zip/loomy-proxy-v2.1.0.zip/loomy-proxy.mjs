#!/usr/bin/env node
/**
 * loomy-proxy v2 —— Loomy 模型网关 → OpenAI 兼容本地反代
 *
 * 上游：https://loomyad.xunfei.cn/api/v1（桌面客户端同一个模型网关）
 * 鉴权：把 Loomy session 同时放进 `token:` 与 `Authorization: Bearer` 两个头
 *       —— /models 只认前者，/chat/completions 只认后者，两个都带最省事。
 *
 * v2 从 wangliangdong/loomy2api 借来并改造的能力：
 *   - 多账号池（桌面 auth-session.json + web-session.json + accounts/*.json 自动发现）
 *   - 额度感知选号：权重 = 额度份额 × 健康度 × 空闲度 ÷ (1+并发)，平滑加权轮询
 *   - 故障分类：鉴权失效（标记重登）/ 429 软冷却 / 5xx 熔断 / 网络错误
 *   - 请求级跨账号故障转移（首字节前才重试）
 *   - /credit 额度快照、/admin 管理面板、日志脱敏
 *
 * 有意不照搬的一点：**不做会话粘性**。上游是 OpenAI 兼容的无状态网关（每次带完整
 * messages，没有服务端会话 ID），跨账号轮询不会丢上下文，粘性在这里没有意义。
 */
import http from 'node:http'
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const VERSION = '2.1.0'

const num = (v, d) => {
  if (v === null || v === undefined || v === '') return d
  const n = Number(v)
  return Number.isFinite(n) ? n : d
}
const envInt = (k, d) => num(process.env[k], d)
const envFloat = (k, d) => num(process.env[k], d)
const envBool = (k, d) => {
  const raw = String(process.env[k] ?? '').trim().toLowerCase()
  return raw ? ['1', 'true', 'yes', 'on'].includes(raw) : d
}

const CONFIG = {
  host: process.env.LOOMY_PROXY_HOST || '127.0.0.1',
  port: envInt('PORT', envInt('LOOMY_PROXY_PORT', 8790)),
  upstream: String(process.env.LOOMY_UPSTREAM || 'https://loomyad.xunfei.cn/api/v1').replace(/\/+$/, ''),
  publicDir: process.env.LOOMY_PUBLIC || 'C:\\Users\\Public\\Loomy',
  accountsDir: process.env.LOOMY_ACCOUNTS_DIR || path.join(__dirname, 'accounts'),
  extraFiles: String(process.env.LOOMY_SESSION_FILES || '').split(path.delimiter).filter(Boolean),
  // 池参数（默认值取自 loomy2api，额度刷新间隔按本项目实测的上游慢响应调大）
  maxInFlight: envInt('POOL_MAX_IN_FLIGHT', 3),
  breakerThreshold: envInt('POOL_BREAKER_THRESHOLD', 3),
  breakerCooldown: envInt('POOL_BREAKER_COOLDOWN', 1800),
  breakerCooldownMax: envInt('POOL_BREAKER_COOLDOWN_MAX', 21600),
  softRateCooldown: envInt('POOL_SOFT_RATE_COOLDOWN', 600),
  softRateCooldownMax: envInt('POOL_SOFT_RATE_COOLDOWN_MAX', 7200),
  quotaFloor: envFloat('POOL_QUOTA_FLOOR', 0.15),
  idleWeightPerHour: envFloat('POOL_IDLE_WEIGHT_PER_HOUR', 0.5),
  idleWeightMax: envFloat('POOL_IDLE_WEIGHT_MAX', 5.0),
  failoverAttempts: envInt('POOL_FAILOVER_ATTEMPTS', 3),
  failoverDeadlineMs: envFloat('POOL_FAILOVER_DEADLINE', 20) * 1000,
  creditRefreshInterval: envInt('CREDIT_REFRESH_INTERVAL', 300) * 1000,
  creditRefreshGap: envFloat('CREDIT_REFRESH_GAP', 1.0) * 1000,
  creditTimeoutMs: envInt('CREDIT_TIMEOUT_MS', 60000),
  discoveryIntervalMs: envInt('DISCOVERY_INTERVAL_MS', 15000),
  modelsCacheMs: envInt('MODELS_CACHE_MS', 300000),
  adminToken: String(process.env.ADMIN_TOKEN || ''),
}

// 兼容 `--port=8790` 形式的命令行参数（启动脚本历史用法）
for (const arg of process.argv.slice(2)) {
  const m = /^--([a-z0-9-]+)=(.*)$/i.exec(arg)
  if (!m) continue
  const key = m[1].toLowerCase()
  if (key === 'port') CONFIG.port = num(m[2], CONFIG.port)
  else if (key === 'host') CONFIG.host = m[2]
  else if (key === 'upstream') CONFIG.upstream = m[2].replace(/\/+$/, '')
  else if (key === 'admin-token') CONFIG.adminToken = m[2]
}

// ---------------------------------------------------------------- 脱敏工具
const mask = (s, head = 6, tail = 4) => {
  const v = String(s || '')
  if (!v) return ''
  if (v.length <= head + tail) return v.slice(0, 2) + '…'
  return `${v.slice(0, head)}…${v.slice(-tail)}`
}
const maskPhone = (p) => String(p || '').replace(/^(\d{3})\d{4}(\d{4})$/, '$1****$2')
const accountIdOf = (session, userid) =>
  'acc_' + crypto.createHash('sha1').update(`${userid || ''}:${session || ''}`).digest('hex').slice(0, 10)

// ---------------------------------------------------------------- 账号状态
/** @type {Map<string, any>} */
const accounts = new Map() // id -> account
let rrTotalWeight = 0

function newAccount(seed) {
  return {
    id: seed.id,
    label: seed.label,
    source: seed.source, // desktop | web | file
    file: seed.file,
    session: seed.session,
    userid: seed.userid || '',
    phone: seed.phone || '',
    updatedAt: seed.updatedAt || 0,
    enabled: true,
    authInvalid: false,
    needsRelogin: false,
    inflight: 0,
    currentWeight: 0,
    requests: 0,
    success: 0,
    errors: 0,
    consecutiveErrors: 0,
    cooldownUntil: 0,
    cooldownLevel: 0,
    rateLimitedUntil: 0,
    lastOkAt: 0,
    lastUsedAt: 0,
    spentSinceCheck: 0,
    lastError: null,
    credit: { availableBalance: null, dailyBalance: null, balance: null, total: null, checkedAt: 0, error: null },
  }
}

function upsertAccount(seed) {
  const existing = accounts.get(seed.id)
  if (!existing) {
    const acc = newAccount(seed)
    accounts.set(acc.id, acc)
    return acc
  }
  // 只更新磁盘上可能变动的字段；运行态（冷却/计数/额度）保留
  existing.session = seed.session
  existing.phone = seed.phone || existing.phone
  existing.userid = seed.userid || existing.userid
  existing.updatedAt = seed.updatedAt || existing.updatedAt
  existing.file = seed.file
  existing.source = seed.source
  existing.label = existing.label || seed.label
  if (existing.authInvalid && seed.updatedAt > existing.lastUsedAt) {
    // 重新登录过：解除鉴权失效标记，重新参与调度
    existing.authInvalid = false
    existing.needsRelogin = false
    existing.cooldownUntil = 0
    existing.cooldownLevel = 0
    existing.consecutiveErrors = 0
    log(`账号 ${existing.id} 授权文件已更新，重新启用`)
  }
  return existing
}

function readSessionFile(file, source, label) {
  try {
    const raw = JSON.parse(fs.readFileSync(file, 'utf8'))
    const session = String(raw.session || '').trim()
    if (!session) return null
    return {
      id: accountIdOf(session, raw.userid),
      label: label || path.basename(path.dirname(file)),
      source,
      file,
      session,
      userid: String(raw.userid || ''),
      phone: String(raw.phone || ''),
      updatedAt: num(raw.updatedAt, 0),
    }
  } catch {
    return null
  }
}

function discoverAccounts() {
  const found = []
  const fileInfo = new Map() // file -> { session, adopted }：用于运行期状态对齐
  // 1) 桌面客户端授权文件：C:\Users\Public\Loomy\<hash>\userData\auth-session.json
  try {
    for (const dir of fs.readdirSync(CONFIG.publicDir, { withFileTypes: true })) {
      if (!dir.isDirectory()) continue
      const file = path.join(CONFIG.publicDir, dir.name, 'userData', 'auth-session.json')
      const seed = readSessionFile(file, 'desktop', `desktop:${dir.name.slice(0, 6)}`)
      if (seed) {
        found.push(seed)
        fileInfo.set(file, { session: seed.session, adopted: true })
      }
    }
  } catch { /* 目录不存在就跳过 */ }
  // 2) 本项目网页登录产物 + 额外账号文件
  const webFile = path.join(__dirname, 'web-session.json')
  const candidates = [webFile, ...CONFIG.extraFiles]
  try {
    for (const f of fs.readdirSync(CONFIG.accountsDir)) {
      if (f.toLowerCase().endsWith('.json')) candidates.push(path.join(CONFIG.accountsDir, f))
    }
  } catch { /* 没有 accounts 目录也正常 */ }
  for (const file of candidates) {
    if (!file || !fs.existsSync(file)) continue
    let raw = {}
    try { raw = JSON.parse(fs.readFileSync(file, 'utf8')) || {} } catch { raw = {} }
    const kind = String(raw?.kind || '')
    // web-session.json 必须带 kind:'gateway-session' 才认：旧的 web-login.mjs（已移入 legacy/）
    // 会把「网页 cookie 会话」写进同一个文件，而 cookie 会话打网关必然 100002「登录已失效」，
    // 一旦放行会把整池鉴权带崩。
    const adoptable = file !== webFile || kind === 'gateway-session'
    const seed = adoptable ? readSessionFile(file, file === webFile ? 'web' : 'file', path.basename(file)) : null
    if (seed) found.push(seed)
    fileInfo.set(file, { session: String(raw?.session || seed?.session || ''), adopted: Boolean(seed) })
  }
  // 去重：同一 session 只保留一个（后发现的覆盖前者，优先保留 desktop/web 明确来源）
  const byId = new Map()
  for (const seed of found) byId.set(seed.id, seed)
  for (const seed of byId.values()) upsertAccount(seed)
  // 运行期状态对齐（v2.0.3）：文件没了 → 需重新登录；文件还在但这一轮**没被采纳**
  // （会话被替换 / gateway-session 标记被去掉 / 内容不合法）→ 同样标记。
  // 老版本只在「文件不存在」时降级，于是曾被采纳过的失效会话会永久留在池里，
  // 配合非流式鉴权误判就是「毒化整池」的残留路径（验证报告 F3）。
  for (const acc of accounts.values()) {
    if (!fs.existsSync(acc.file)) {
      acc.authInvalid = true
      acc.needsRelogin = true
      acc.lastError = '授权文件已不存在'
      continue
    }
    const info = fileInfo.get(acc.file)
    if (!info) continue // 本轮没扫到该文件（例如临时读失败）：保持原状态，避免误驱逐
    if (info.adopted && info.session === acc.session) continue
    acc.authInvalid = true
    acc.needsRelogin = true
    acc.lastError = info.session && info.session !== acc.session
      ? '授权文件中的会话已被替换'
      : '授权文件已失效（缺少 gateway-session 标记或内容不合法）'
  }
  return byId.size
}

// ---------------------------------------------------------------- 池调度
const now = () => Date.now()
const isCooling = (a) => a.cooldownUntil > now() || a.rateLimitedUntil > now()

function usableAccounts() {
  return [...accounts.values()].filter(
    (a) => a.enabled && !a.authInvalid && a.session && !isCooling(a) && a.inflight < CONFIG.maxInFlight,
  )
}

function weightOf(a, pool) {
  const balances = pool.map((x) => num(x.credit.availableBalance, 0))
  const maxBalance = Math.max(1, ...balances)
  // 额度未知（还没刷出来 / 刷新失败）的账号不能给最高权重：老写法给 1 会让坏账号比健康账号更容易被选中，
  // 反而放大鉴权故障的暴露面（验证报告 O5）。给 0.5：低于任何额度充足的正常账号，又高于 quotaFloor。
  const quotaShare = a.credit.availableBalance == null ? 0.5 : Math.max(CONFIG.quotaFloor, num(a.credit.availableBalance, 0) / maxBalance)
  const health = (1 + a.success) / (1 + a.success + 3 * a.errors)
  const idleHours = a.lastOkAt ? (now() - a.lastOkAt) / 3600000 : 24
  const idleness = Math.min(CONFIG.idleWeightMax, 1 + idleHours * CONFIG.idleWeightPerHour)
  return (quotaShare * health * idleness) / (1 + a.inflight)
}

/** 平滑加权轮询（SWRR）：权重平滑分配，不会出现突发。 */
function selectAccount() {
  const pool = usableAccounts()
  if (pool.length === 0) return null
  const total = pool.reduce((sum, a) => sum + weightOf(a, pool), 0)
  let picked = null
  for (const a of pool) {
    a.currentWeight += weightOf(a, pool)
    if (!picked || a.currentWeight > picked.currentWeight) picked = a
  }
  if (picked) {
    picked.currentWeight -= total
    rrTotalWeight += total
  }
  return picked
}

function markSuccess(a) {
  a.requests++
  a.success++
  a.consecutiveErrors = 0
  a.lastOkAt = now()
  a.lastUsedAt = now()
  a.lastError = null
}

function markAuthInvalid(a, reason) {
  a.requests++
  a.errors++
  a.authInvalid = true
  a.needsRelogin = true
  a.lastUsedAt = now()
  a.lastError = `鉴权失效：${reason}`
  log(`账号 ${a.id} 鉴权失效，已移出调度（需重新登录）`)
}

function markRateLimited(a, reason) {
  a.requests++
  a.errors++
  a.cooldownLevel = Math.min(a.cooldownLevel + 1, 5)
  const ms = Math.min(CONFIG.softRateCooldownMax, CONFIG.softRateCooldown) * 1000 * 2 ** (a.cooldownLevel - 1)
  a.rateLimitedUntil = now() + ms
  a.lastUsedAt = now()
  a.lastError = `限流：${reason}（冷却 ${Math.round(ms / 1000)}s）`
  log(`账号 ${a.id} 触发限流，冷却 ${Math.round(ms / 1000)}s`)
}

function markUpstreamError(a, reason) {
  a.requests++
  a.errors++
  a.consecutiveErrors++
  a.lastUsedAt = now()
  if (a.consecutiveErrors >= CONFIG.breakerThreshold) {
    a.cooldownLevel = Math.min(a.cooldownLevel + 1, 5)
    const ms = Math.min(CONFIG.breakerCooldownMax, CONFIG.breakerCooldown) * 1000 * 2 ** (a.cooldownLevel - 1)
    a.cooldownUntil = now() + ms
    a.lastError = `熔断：${reason}（冷却 ${Math.round(ms / 1000)}s）`
    log(`账号 ${a.id} 连续 ${a.consecutiveErrors} 次上游错误，熔断 ${Math.round(ms / 1000)}s`)
  } else {
    a.lastError = `上游错误：${reason}`
  }
}

function classify(status, bodyText) {
  const text = String(bodyText || '')
  let code = ''
  let desc = ''
  try {
    const parsed = JSON.parse(text)
    code = String(parsed?.code || '')
    desc = String(parsed?.desc || parsed?.message || '')
  } catch { /* 非 JSON 响应 */ }
  const blob = `${code} ${desc} ${text.slice(0, 400)}`.toLowerCase()
  if (status === 401 || status === 403 || code === '100002' || /登录已失效|未登录|缺少 token|unauthor|invalid session|token expired/.test(blob)) {
    return { cls: 'auth', desc: desc || `HTTP ${status}` }
  }
  if (status === 429 || /rate limit|too many requests|限流|请求过于频繁/.test(blob)) {
    return { cls: 'rate', desc: desc || 'HTTP 429' }
  }
  if (status >= 500 || [408, 409, 425].includes(status)) {
    return { cls: 'upstream', desc: desc || `HTTP ${status}` }
  }
  return { cls: 'client', desc: desc || `HTTP ${status}` }
}

// ---------------------------------------------------------------- 额度
async function fetchCredit(acc) {
  const url = `${CONFIG.upstream}/points/records?pageNo=1&pageSize=1&recordType=all`
  const ctl = new AbortController()
  const timer = setTimeout(() => ctl.abort(), CONFIG.creditTimeoutMs)
  const t0 = Date.now()
  try {
    const res = await fetch(url, {
      headers: { token: acc.session, authorization: `Bearer ${acc.session}` },
      signal: ctl.signal,
    })
    const text = await res.text()
    const parsed = JSON.parse(text)
    if (parsed?.code !== '000000') throw new Error(parsed?.desc || String(parsed?.code || res.status))
    const d = parsed.data || {}
    acc.credit = {
      availableBalance: num(d.availableBalance, null),
      dailyBalance: num(d.dailyBalance, null),
      balance: num(d.balance, null),
      total: num(d.total, null),
      checkedAt: now(),
      error: null,
    }
    log(`额度刷新 ${acc.id} 用时 ${Math.round((Date.now() - t0) / 1000)}s：可用 ${acc.credit.availableBalance ?? '?'}（日 ${acc.credit.dailyBalance ?? '?'} / 总 ${acc.credit.balance ?? '?'}）`)
    return acc.credit
  } catch (err) {
    acc.credit = { ...acc.credit, checkedAt: now(), error: String(err?.message || err) }
    log(`额度刷新失败 ${acc.id} 用时 ${Math.round((Date.now() - t0) / 1000)}s：${err?.name || ''} ${err?.message || err}`)
    return acc.credit
  } finally {
    clearTimeout(timer)
  }
}

let creditRefreshing = false
/**
 * 增量刷新额度：每 30s 走一遍账号，只刷新「缓存过期」且「当前空闲」的账号。
 * v2.0.0 的写法是「每个刷新周期全量刷一遍、忙的账号直接跳过」，结果本机 DSH 一直在用
 * 反代（总有在途请求）时，第二个账号的额度永远刷不到 → v2.0.1 改成增量重试。
 */
async function refreshAllCredits({ force = false } = {}) {
  if (creditRefreshing) return { skipped: true }
  creditRefreshing = true
  try {
    for (const acc of accounts.values()) {
      if (!acc.session || acc.authInvalid) continue
      const age = acc.credit.checkedAt ? now() - acc.credit.checkedAt : Infinity
      if (!force && age < CONFIG.creditRefreshInterval) continue
      if (!force && acc.inflight > 0) continue
      await fetchCredit(acc)
      await new Promise((r) => setTimeout(r, CONFIG.creditRefreshGap))
    }
    return { ok: true }
  } finally {
    creditRefreshing = false
  }
}

// ---------------------------------------------------------------- 模型清单
let modelsCache = { at: 0, data: [], aliases: new Map() }
const STATIC_MODELS = [
  { id: 'DeepSeek-V4.1-Flash', context_length: 1048576, max_output_tokens: 384000 },
  { id: 'deepseek-v4-flash-0731', context_length: 1048576, max_output_tokens: 384000 },
  { id: 'MiniMax-M3', context_length: 1048576, max_output_tokens: 512000 },
  { id: 'Kimi-k2.6', context_length: 262144, max_output_tokens: 65536 },
  { id: 'qwen-3.8-max', context_length: 1000000, max_output_tokens: 65536 },
  { id: 'GLM-5.3-Flash', context_length: 1048576, max_output_tokens: 131072 },
  { id: 'qwen3.8-flash', context_length: 1000000, max_output_tokens: 131072 },
  { id: 'spark-x', context_length: 1048576, max_output_tokens: 65536 },
  { id: 'mimo-v2.5', context_length: 1048576, max_output_tokens: 131072 },
]
const FIXED_ALIASES = new Map([
  ['deepseek-v4.1-flash', 'DeepSeek-V4.1-Flash'],
  ['deepseek-v4-flash', 'deepseek-v4-flash-0731'],
])

async function loadModels({ force = false } = {}) {
  if (!force && modelsCache.data.length && now() - modelsCache.at < CONFIG.modelsCacheMs) return modelsCache
  const acc = selectAccount() || [...accounts.values()].find((a) => a.session && !a.authInvalid)
  let list = STATIC_MODELS
  if (acc) {
    try {
      const res = await fetch(`${CONFIG.upstream}/models`, { headers: { token: acc.session, authorization: `Bearer ${acc.session}` } })
      const text = await res.text()
      const parsed = JSON.parse(text)
      const data = Array.isArray(parsed) ? parsed : Array.isArray(parsed?.data) ? parsed.data : null
      if (data?.length) {
        list = data
        log(`模型清单已从上游刷新：${data.length} 个（账号 ${acc.id}）`)
      } else {
        log(`上游 /models 未返回数组，沿用本地静态清单（${mask(text, 40, 20)}）`)
      }
    } catch (err) {
      log(`上游 /models 拉取失败：${err?.message || err}，沿用本地静态清单`)
    }
  }
  const aliases = new Map(FIXED_ALIASES)
  const out = []
  for (const m of list) {
    const id = String(m?.id || '').trim()
    if (!id) continue
    out.push({ ...m, id, object: 'model', owned_by: m?.owned_by || 'loomy' })
    const lower = id.toLowerCase()
    if (lower !== id) {
      aliases.set(lower, id)
      out.push({ ...m, id: lower, object: 'model', owned_by: m?.owned_by || 'loomy', alias_of: id })
    }
  }
  modelsCache = { at: now(), data: out, aliases }
  return modelsCache
}

function resolveModel(requested) {
  const raw = String(requested || '').trim()
  if (!raw) return null
  const exact = modelsCache.data.find((m) => m.id === raw)
  if (exact && !exact.alias_of) return exact.id
  if (modelsCache.aliases.has(raw.toLowerCase())) return modelsCache.aliases.get(raw.toLowerCase())
  const byLower = modelsCache.data.find((m) => m.id.toLowerCase() === raw.toLowerCase() && !m.alias_of)
  if (byLower) return byLower.id
  return null
}

// ---------------------------------------------------------------- 上游调用
function upstreamHeaders(acc, extra = {}) {
  return {
    // /models 只认 token，/chat/completions 只认 Bearer —— 两个都带，最省事
    token: acc.session,
    authorization: `Bearer ${acc.session}`,
    ...extra,
  }
}

async function callChat(acc, payload) {
  const ctl = new AbortController()
  const timer = setTimeout(() => ctl.abort(), envInt('UPSTREAM_TIMEOUT_MS', 1200000))
  try {
    const res = await fetch(`${CONFIG.upstream}/chat/completions`, {
      method: 'POST',
      headers: upstreamHeaders(acc, { 'content-type': 'application/json', accept: 'text/event-stream, application/json' }),
      body: JSON.stringify(payload),
      signal: ctl.signal,
    })
    return { res, ctl, timer }
  } catch (err) {
    clearTimeout(timer)
    throw err
  }
}

/**
 * 提取一次响应里的额度消耗。实测上游同一次 SSE 会把 points_consumed 推两次（落在不同 TCP chunk），
 * 老写法按 chunk 累加会 +1/+2 抖动、额度计数超过请求数（验证报告 F1），故改成「取最大值、每个响应只加一次」。
 */
function extractPoints(text) {
  let max = 0
  for (const m of String(text || '').matchAll(/"points_consumed"\s*:\s*(\d+)/g)) max = Math.max(max, num(m[1], 0))
  return max
}

/** 上游业务错误信封：HTTP 200 但 body 是 {"code":"100002","desc":"登录已失效…"}（没有 choices） */
function looksLikeErrorEnvelope(text) {
  try {
    const j = JSON.parse(String(text || ''))
    if (!j || typeof j !== 'object') return false
    if (Array.isArray(j.choices) && j.choices.length > 0) return false
    return Boolean(j.code || j.desc || j.error || j.message)
  } catch { return false }
}

// ---------------------------------------------------------------- HTTP 层
function json(res, status, body) {
  const text = JSON.stringify(body, null, 2)
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
  res.end(text)
}

function readBody(req, limitBytes = 64 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = []
    let size = 0
    let exceeded = false
    req.on('data', (c) => {
      if (exceeded) return
      size += c.length
      if (size > limitBytes) {
        exceeded = true
        const err = new Error('请求体过大')
        err.statusCode = 413
        reject(err)
        // 排掉剩余数据，让调用方还能回一个 413 JSON；老写法 req.destroy() 会让客户端只看到连接被重置
        // （验证报告 F4/O2：管理面超限 body 被当成 enabled:false 静默禁用账号）
        req.resume()
        return
      }
      chunks.push(c)
    })
    req.on('end', () => { if (!exceeded) resolve(Buffer.concat(chunks)) })
    req.on('error', (err) => { if (!exceeded) reject(err) })
  })
}

const log = (msg) => console.log(`[${new Date().toISOString()}] ${msg}`)

// ---------------------------------------------------------------- 每日签到（daily-tasks.mjs）
// 反代只负责「读状态 + 触发脚本」，任务逻辑全在 daily-tasks.mjs 里，避免两份实现漂移。
const DAILY = {
  script: path.join(__dirname, 'daily-tasks.mjs'),
  stateFile: process.env.LOOMY_DAILY_STATE || path.join(__dirname, 'daily-tasks-state.json'),
  logFile: path.join(__dirname, 'logs', 'daily-tasks-run.log'),
  running: false,
  startedAt: 0,
  finishedAt: 0,
  code: null,
  lastApply: null,
}

function readDailyState() {
  try {
    const raw = JSON.parse(fs.readFileSync(DAILY.stateFile, 'utf8'))
    const ranMs = raw?.ranAt ? Date.parse(raw.ranAt) : 0
    return {
      ran_at: raw?.ranAt || null,
      age_s: ranMs ? Math.max(0, Math.round((Date.now() - ranMs) / 1000)) : null,
      mode: raw?.mode || null,
      summary: raw?.summary || null,
      accounts: (raw?.accounts || []).map((a) => ({
        id: a.id,
        label: a.label,
        source: a.source,
        phone: a.phone,
        userid: a.userid,
        ok: a.ok,
        balance: a.balance || null,
        onboarding: a.onboarding
          ? { done: a.onboarding.done, total: a.onboarding.total, earnedPoints: a.onboarding.earnedPoints, totalPoints: a.onboarding.totalPoints }
          : null,
        petwork: a.petwork
          ? {
            businessDate: a.petwork.businessDate,
            earnedPointsToday: a.petwork.earnedPointsToday,
            rewardedTierIds: a.petwork.rewardedTierIds || [],
            dailyRewardCapped: a.petwork.dailyRewardCapped,
          }
          : null,
        actions: a.actions || [],
        skipped: a.skipped || [],
        errors: a.errors || [],
      })),
    }
  } catch {
    return null
  }
}

function tailText(file, maxChars = 4000) {
  try {
    const t = fs.readFileSync(file, 'utf8')
    return t.length > maxChars ? t.slice(-maxChars) : t
  } catch {
    return ''
  }
}

function dailyRunStatus(includeTail = false) {
  return {
    running: DAILY.running,
    started_at: DAILY.startedAt || null,
    finished_at: DAILY.finishedAt || null,
    exit_code: DAILY.code,
    last_apply: DAILY.lastApply,
    duration_s: DAILY.running && DAILY.startedAt
      ? Math.round((Date.now() - DAILY.startedAt) / 1000)
      : DAILY.startedAt && DAILY.finishedAt ? Math.round((DAILY.finishedAt - DAILY.startedAt) / 1000) : null,
    ...(includeTail ? { log_tail: tailText(DAILY.logFile) } : {}),
  }
}

/**
 * 触发 daily-tasks.mjs。
 * 用「文件描述符重定向」而不是管道：宿主若对子进程管道有限制（Windows 沙箱下 node 的
 * stdio:'pipe' 可能 EPERM），fd 重定向在所有环境下都能工作，代价是要借日志文件拿输出。
 */
function runDailyTasks({ apply = false } = {}) {
  if (DAILY.running) return { ok: false, error: '已有签到任务在运行中，请稍候', ...dailyRunStatus() }
  if (!fs.existsSync(DAILY.script)) return { ok: false, error: `找不到签到脚本：${DAILY.script}` }
  try {
    fs.mkdirSync(path.dirname(DAILY.logFile), { recursive: true })
  } catch { /* 日志目录不可写也不阻断 */ }
  let fd
  try {
    fd = fs.openSync(DAILY.logFile, 'a')
  } catch (err) {
    return { ok: false, error: `无法打开签到日志：${err?.message || err}` }
  }
  let fdClosed = false
  const closeFd = () => { if (!fdClosed) { fdClosed = true; try { fs.closeSync(fd) } catch { /* 已关闭 */ } } }
  try {
    fs.writeSync(fd, `\n[${new Date().toISOString()}] 由管理面板触发：node daily-tasks.mjs ${apply ? '--apply' : '(只读检查)'}\n`)
  } catch { /* 忽略写入失败 */ }

  DAILY.running = true
  DAILY.startedAt = Date.now()
  DAILY.finishedAt = 0
  DAILY.code = null
  DAILY.lastApply = apply

  let child
  try {
    child = spawn(process.execPath, apply ? [DAILY.script, '--apply'] : [DAILY.script], {
      cwd: __dirname,
      stdio: ['ignore', fd, fd],
      windowsHide: true,
    })
  } catch (err) {
    closeFd()
    DAILY.running = false
    return { ok: false, error: `启动签到脚本失败：${err?.message || err}` }
  }

  const finish = (code, note) => {
    closeFd()
    DAILY.running = false
    DAILY.finishedAt = Date.now()
    DAILY.code = code
    log(`签到任务结束（${apply ? '--apply' : '只读'}）${note}退出码 ${code}，用时 ${Math.round((DAILY.finishedAt - DAILY.startedAt) / 1000)}s`)
  }
  child.on('close', (code) => finish(code, ''))
  child.on('error', (err) => finish(-1, `错误 ${err?.message || err}，`))
  const killer = setTimeout(() => {
    log('签到任务超过 15 分钟，强制结束')
    try { child.kill() } catch { /* 已退出 */ }
  }, 15 * 60 * 1000)
  killer.unref?.()

  log(`签到任务已启动（${apply ? '--apply' : '只读'}），输出见 ${DAILY.logFile}`)
  return { ok: true, ...dailyRunStatus() }
}

function snapshot() {
  const list = [...accounts.values()].map((a) => ({
    id: a.id,
    label: a.label,
    source: a.source,
    phone: maskPhone(a.phone),
    userid: a.userid ? mask(a.userid, 6, 3) : '',
    session: mask(a.session, 6, 4),
    enabled: a.enabled,
    state: !a.enabled ? 'disabled'
      : a.authInvalid ? 'needs_relogin'
      : isCooling(a) ? (a.rateLimitedUntil > now() ? 'rate_limited' : 'cooling')
      : a.credit.availableBalance === 0 ? 'exhausted'
      : a.credit.error ? 'degraded'
      : 'ok',
    healthy: !a.authInvalid && !isCooling(a),
    inflight: a.inflight,
    requests: a.requests,
    success: a.success,
    errors: a.errors,
    consecutive_errors: a.consecutiveErrors,
    available_balance: a.credit.availableBalance,
    daily_balance: a.credit.dailyBalance,
    total_balance: a.credit.balance,
    spent_since_check: a.spentSinceCheck,
    credit_checked_at: a.credit.checkedAt || null,
    credit_age_s: a.credit.checkedAt ? Math.round((now() - a.credit.checkedAt) / 1000) : null,
    credit_error: a.credit.error,
    cooldown_remaining_s: Math.max(0, Math.round((Math.max(a.cooldownUntil, a.rateLimitedUntil) - now()) / 1000)),
    last_ok_at: a.lastOkAt || null,
    last_error: a.lastError,
    file: a.file,
  }))
  const usable = list.filter((a) => a.healthy && a.enabled).length
  // 同一 Loomy 账号可能同时存在桌面授权 + 网页登录两份 session，额度合计要去重
  const uniqueBalance = new Map()
  for (const a of list) {
    const key = a.userid || a.id
    if (a.available_balance != null && !uniqueBalance.has(key)) uniqueBalance.set(key, num(a.available_balance, 0))
  }
  return {
    service: 'loomy-proxy',
    version: VERSION,
    upstream: CONFIG.upstream,
    mode: list.length >= 2 ? 'pool' : 'single',
    accounts_total: list.length,
    accounts_usable: usable,
    accounts: list,
    total: {
      available_balance: uniqueBalance.size ? [...uniqueBalance.values()].reduce((s, v) => s + v, 0) : null,
      requests: list.reduce((s, a) => s + a.requests, 0),
      success: list.reduce((s, a) => s + a.success, 0),
      errors: list.reduce((s, a) => s + a.errors, 0),
    },
    ts: Math.floor(now() / 1000),
  }
}

function adminAuthorized(req) {
  if (!CONFIG.adminToken) return false
  const header = String(req.headers['x-admin-token'] || '')
  const bearer = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '')
  return header === CONFIG.adminToken || bearer === CONFIG.adminToken
}

function adminPage() {
  const s = snapshot()
  const d = readDailyState()
  const dt = dailyRunStatus()
  const dailyRows = (d?.accounts || []).map((a) => `
    <tr>
      <td>${a.label || ''}<div class="dim">${a.id} · ${a.source} · ${a.phone || ''}</div></td>
      <td>${a.onboarding ? `${a.onboarding.done}/${a.onboarding.total}` : '—'}<div class="dim">${a.onboarding ? `${a.onboarding.earnedPoints}/${a.onboarding.totalPoints} 分` : ''}</div></td>
      <td>${a.petwork ? `${a.petwork.earnedPointsToday} 分` : '—'}<div class="dim">${a.petwork ? `已领 [${(a.petwork.rewardedTierIds || []).join(', ') || '无'}]${a.petwork.dailyRewardCapped ? ' · 封顶' : ''}` : ''}</div></td>
      <td>${a.balance?.availableBalance ?? '—'}<div class="dim">今日额度 ${a.balance?.dailyBalance ?? '—'}</div></td>
      <td class="dim">${(a.actions || []).join('；') || '—'}${(a.skipped || []).length ? `<div>跳过：${(a.skipped || []).join('；')}</div>` : ''}${(a.errors || []).length ? `<div class="warn">错误：${(a.errors || []).join('；')}</div>` : ''}</td>
    </tr>`).join('')
  const rows = s.accounts.map((a) => `
    <tr>
      <td>${a.label || ''}<div class="dim">${a.id} · ${a.source}</div></td>
      <td class="${a.state === 'ok' ? 'ok' : 'warn'}">${a.state}</td>
      <td>${a.available_balance ?? '—'}<div class="dim">日 ${a.daily_balance ?? '—'} · 总 ${a.total_balance ?? '—'}</div></td>
      <td>${a.requests} / <span class="ok">${a.success}</span> / <span class="warn">${a.errors}</span><div class="dim">并发 ${a.inflight}</div></td>
      <td>${a.phone || '—'}<div class="dim">${a.session} · ${a.userid || ''}</div></td>
      <td>${a.cooldown_remaining_s ? a.cooldown_remaining_s + 's' : '—'}</td>
      <td class="dim">${a.last_error || '—'}</td>
    </tr>`).join('')
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<title>loomy-proxy ${VERSION}</title><meta http-equiv="refresh" content="5">
<style>
 body{font:13px/1.6 ui-monospace,Consolas,monospace;background:#111;color:#ddd;margin:24px}
 h1{font-size:16px;margin:0 0 4px} table{border-collapse:collapse;width:100%;margin-top:14px}
 th,td{border-bottom:1px solid #2a2a2a;padding:6px 8px;text-align:left;vertical-align:top}
 th{color:#888;font-weight:600} .dim{color:#777;font-size:11px} .ok{color:#4ec9b0} .warn{color:#e0a458}
 a{color:#6cb6ff} .pill{background:#1d1d1d;border:1px solid #2a2a2a;border-radius:10px;padding:2px 8px;margin-right:6px}
 h2{font-size:14px;margin:24px 0 6px}
 button{background:#1d1d1d;color:#ddd;border:1px solid #333;border-radius:6px;padding:4px 10px;cursor:pointer;margin-right:8px;font:inherit}
 button:hover{border-color:#6cb6ff;color:#fff}
</style></head><body>
<h1>loomy-proxy <span class="dim">v${VERSION}</span></h1>
<div><span class="pill">模式 ${s.mode}</span><span class="pill">账号 ${s.accounts_usable}/${s.accounts_total} 可用</span>
<span class="pill">上游 ${s.upstream}</span><span class="pill">5s 自动刷新</span></div>
<table><thead><tr><th>账号</th><th>状态</th><th>可用额度</th><th>请求/成功/失败</th><th>手机号 · session</th><th>冷却</th><th>最近错误</th></tr></thead>
<tbody>${rows || '<tr><td colspan="7" class="dim">未发现账号</td></tr>'}</tbody></table>
<h2>今日签到 <span class="dim">daily-tasks.mjs</span></h2>
<div><span class="pill">最近执行 ${d?.ran_at ? `${d.ran_at}${d.age_s != null ? `（${Math.round(d.age_s / 60)} 分钟前）` : ''}` : '尚未执行'}</span>
<span class="pill">模式 ${d?.mode || '—'}</span>
<span class="pill">${dt.running ? `运行中 ${dt.duration_s ?? 0}s` : '空闲'}</span>
<span class="pill">新手任务 ${d?.summary ? `${d.summary.onboardingDone}/${d.summary.onboardingTotal}` : '—'}</span>
<span class="pill">可用余额 ${d?.summary?.availableBalance ?? '—'}</span></div>
<table><thead><tr><th>账号</th><th>新手任务</th><th>今日打工</th><th>可用余额</th><th>本次动作</th></tr></thead>
<tbody>${dailyRows || '<tr><td colspan="5" class="dim">还没有签到记录：点下面的按钮，或运行 start-loomy-daily.cmd</td></tr>'}</tbody></table>
<p>
<button onclick="runDaily(false)">只读检查</button>
<button onclick="runDaily(true)">执行签到（--apply）</button>
<span class="dim">领取接口是幂等的；打工奖励只在本地能找到客户端真实活动记录时才领取，找不到就跳过（不伪造数据）。</span>
</p>
<script>
async function runDaily(apply) {
  const token = prompt('X-Admin-Token（未配置 ADMIN_TOKEN 时留空）')
  if (token === null) return
  try {
    const r = await fetch('/admin/api/daily/run', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-admin-token': token },
      body: JSON.stringify({ apply }),
    })
    const j = await r.json()
    if (!j.ok) alert('触发失败：' + (j.error || r.status))
    else alert(apply ? '已开始执行签到（--apply），几秒后自动刷新' : '已开始只读检查，几秒后自动刷新')
  } catch (err) {
    alert('触发失败：' + err)
  }
  location.reload()
}
</script>
<p class="dim">JSON 快照：<a href="/credit">/credit</a> · 账号 API：<a href="/admin/api/accounts">/admin/api/accounts</a>
${CONFIG.adminToken ? ' · 写操作需 <code>X-Admin-Token</code>' : ' · 未配置 ADMIN_TOKEN，写操作已禁用'}</p>
</body></html>`
}

function handleCreditRefreshTrigger(res) {
  refreshAllCredits({ force: true })
    .then(() => json(res, 200, { ok: true, ...snapshot() }))
    .catch((err) => json(res, 500, { ok: false, error: String(err?.message || err) }))
}

async function handleChat(req, res) {
  let payload
  try {
    payload = JSON.parse((await readBody(req)).toString('utf8'))
  } catch (err) {
    if (err?.statusCode === 413) {
      return json(res, 413, { error: { message: '请求体过大（上限 64 MiB）', type: 'invalid_request_error' } })
    }
    return json(res, 400, { error: { message: `请求体不是合法 JSON：${err?.message || err}`, type: 'invalid_request_error' } })
  }
  await loadModels()
  const requested = payload?.model
  const canonical = resolveModel(requested)
  if (!canonical) {
    return json(res, 400, { error: { message: `Unsupported model: ${requested}`, type: 'invalid_request_error', code: 'model_not_found' } })
  }
  payload.model = canonical
  const stream = Boolean(payload?.stream)
  const started = now()
  const tried = new Set()
  let lastFailure = null

  for (let attempt = 1; attempt <= CONFIG.failoverAttempts; attempt++) {
    if (now() - started > CONFIG.failoverDeadlineMs) {
      lastFailure = lastFailure || { status: 504, body: '{"error":{"message":"故障转移超出时间预算"}}' }
      break
    }
    const acc = selectAccount()
    if (!acc) break
    if (tried.has(acc.id) && usableAccounts().length > tried.size) continue
    tried.add(acc.id)
    acc.inflight++
    let handle
    try {
      handle = await callChat(acc, payload)
    } catch (err) {
      acc.inflight--
      markUpstreamError(acc, `网络错误 ${err?.message || err}`)
      lastFailure = { status: 502, body: JSON.stringify({ error: { message: `上游不可达：${err?.message || err}` } }) }
      continue
    }

    const { res: upstream, ctl, timer } = handle
    const ctype = String(upstream.headers.get('content-type') || '')
    const looksJson = ctype.includes('application/json')

    if (!upstream.ok || (stream && looksJson)) {
      const text = await upstream.text().catch(() => '')
      clearTimeout(timer)
      acc.inflight--
      const { cls, desc } = classify(upstream.status, text)
      if (cls === 'auth') { markAuthInvalid(acc, desc); lastFailure = { status: 502, body: text }; continue }
      if (cls === 'rate') { markRateLimited(acc, desc); lastFailure = { status: 429, body: text }; continue }
      if (cls === 'upstream') { markUpstreamError(acc, desc); lastFailure = { status: upstream.status, body: text }; continue }
      // 客户端错误：不是账号的问题，原样回给调用方
      res.writeHead(upstream.status, { 'content-type': ctype || 'application/json; charset=utf-8' })
      res.end(text)
      log(`chat 客户端错误 model=${canonical} status=${upstream.status}`)
      return
    }

    if (!stream) {
      const text = await upstream.text().catch(() => '')
      clearTimeout(timer)
      acc.inflight--
      // 关键（验证报告 F2）：上游鉴权失败返回的是 HTTP 200 + {"code":"100002","desc":"登录已失效…"}
      // 而**不是** 401/403。非流式路径以前无条件 markSuccess + 原样透传 —— 坏账号被计为成功、
      // 永不故障转移、日志还打印 "chat ok"。这里必须先判错误信封，再决定成功/换号。
      if (looksJson && looksLikeErrorEnvelope(text)) {
        const { cls, desc } = classify(upstream.status, text)
        if (cls === 'auth') { markAuthInvalid(acc, desc); lastFailure = { status: 502, body: text }; continue }
        if (cls === 'rate') { markRateLimited(acc, desc); lastFailure = { status: 429, body: text }; continue }
        if (cls === 'upstream') { markUpstreamError(acc, desc); lastFailure = { status: upstream.status, body: text }; continue }
        res.writeHead(upstream.status, { 'content-type': ctype || 'application/json; charset=utf-8' })
        res.end(text)
        log(`chat 客户端错误 model=${canonical} status=${upstream.status}`)
        return
      }
      markSuccess(acc)
      acc.spentSinceCheck += extractPoints(text) // 每个响应只加一次（F1）
      res.writeHead(200, { 'content-type': ctype || 'application/json; charset=utf-8', 'cache-control': 'no-store' })
      res.end(text)
      log(`chat ok model=${canonical} account=${acc.id} 用时 ${Math.round((now() - started) / 1000)}s`)
      return
    }
    markSuccess(acc)

    // 流式：首字节已就绪，之后不再故障转移
    res.writeHead(200, {
      'content-type': ctype || 'text/event-stream; charset=utf-8',
      'cache-control': 'no-cache, no-store',
      connection: 'keep-alive',
      'x-accel-buffering': 'no',
    })
    let carry = ''
    let tapBuf = ''
    try {
      for await (const chunk of upstream.body) {
        const buf = Buffer.from(chunk)
        const s = buf.toString('utf8')
        carry += s
        if (carry.length > 4096) carry = carry.slice(-1024)
        // 只在含 points_consumed 的窗口取样，流结束后统一取最大值加一次（F1：逐 chunk 累加会 +1/+2 抖动）
        if (carry.includes('points_consumed')) {
          if (tapBuf.length < 8192) tapBuf += carry
          carry = ''
        }
        res.write(buf)
      }
    } catch (err) {
      log(`流式中断 account=${acc.id}：${err?.message || err}`)
    } finally {
      clearTimeout(timer)
      acc.inflight--
      acc.spentSinceCheck += extractPoints(tapBuf)
      res.end()
      log(`chat stream ok model=${canonical} account=${acc.id} 用时 ${Math.round((now() - started) / 1000)}s`)
    }
    return
  }

  const fallback = lastFailure || { status: 503, body: JSON.stringify({ error: { message: '没有可用账号：请在 Loomy 客户端登录，或访问 http://127.0.0.1:8791 用网页登录' } }) }
  res.writeHead(fallback.status, { 'content-type': 'application/json; charset=utf-8' })
  res.end(fallback.body)
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`)
  const p = url.pathname
  try {
    if (p === '/health') {
      const s = snapshot()
      // 全部账号失效时不要回退到 accounts[0]（会让 auth_file/auth_source 看起来还有有效授权，
      // 验证报告 O4）；改为只报健康账号，没有就给 null，配合 accounts_usable=0 判断。
      const primary = s.accounts.find((a) => a.enabled && a.healthy) || null
      return json(res, 200, {
        ok: true,
        service: 'loomy-proxy',
        version: VERSION,
        upstream: CONFIG.upstream,
        mode: s.mode,
        accounts_total: s.accounts_total,
        accounts_usable: s.accounts_usable,
        auth_file: primary?.file || null,
        auth_source: primary?.source || null,
        phone: primary?.phone || null,
        userid: primary?.userid || null,
        available_balance: primary?.available_balance ?? null,
        model_count: modelsCache.data.length || null,
        daily_tasks: {
          last_run_at: readDailyState()?.ran_at || null,
          last_mode: readDailyState()?.mode || null,
          running: DAILY.running,
        },
      })
    }
    if (p === '/credit') {
      if (url.searchParams.get('refresh') === '1') return handleCreditRefreshTrigger(res)
      return json(res, 200, snapshot())
    }
    if (p === '/admin') {
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' })
      return res.end(adminPage())
    }
    if (p === '/admin/api/accounts') return json(res, 200, snapshot())
    // 每日签到：读状态不需要令牌（与 /admin/api/accounts 一致），触发写操作需要
    if (p === '/admin/api/daily') {
      return json(res, 200, { ok: true, state: readDailyState(), run: dailyRunStatus(true) })
    }
    if (p === '/admin/api/daily/run' && req.method === 'POST') {
      if (!adminAuthorized(req)) return json(res, 403, { error: '写操作需要 X-Admin-Token' })
      let apply = false
      try {
        const raw = (await readBody(req, 4096)).toString('utf8').trim()
        if (raw) {
          const body = JSON.parse(raw)
          apply = body?.apply === true || body?.apply === 'true'
        }
      } catch (err) {
        return json(res, err?.statusCode === 413 ? 413 : 400, { error: `请求体过大或不是合法 JSON：${err?.message || err}` })
      }
      const r = runDailyTasks({ apply })
      return json(res, r.ok ? 202 : 409, r)
    }
    if (p === '/admin/api/refresh' && req.method === 'POST') {
      if (!adminAuthorized(req)) return json(res, 403, { error: '写操作需要 X-Admin-Token' })
      return handleCreditRefreshTrigger(res)
    }
    const enableMatch = /^\/admin\/api\/accounts\/([^/]+)\/enabled$/.exec(p)
    if (enableMatch && req.method === 'POST') {
      if (!adminAuthorized(req)) return json(res, 403, { error: '写操作需要 X-Admin-Token' })
      const acc = accounts.get(decodeURIComponent(enableMatch[1]))
      if (!acc) return json(res, 404, { error: 'account not found' })
      let body
      try {
        body = JSON.parse((await readBody(req, 4096)).toString('utf8') || '{}')
      } catch (err) {
        // 老写法 catch 掉异常后 body 仍是 {}，Boolean(undefined) === false → 超限/畸形请求静默禁用账号（F4）
        return json(res, err?.statusCode === 413 ? 413 : 400, { error: `请求体过大或不是合法 JSON：${err?.message || err}` })
      }
      if (typeof body?.enabled !== 'boolean') return json(res, 400, { error: '缺少布尔字段 enabled' })
      acc.enabled = body.enabled
      if (acc.enabled) { acc.cooldownUntil = 0; acc.rateLimitedUntil = 0; acc.consecutiveErrors = 0 }
      log(`账号 ${acc.id} 已${acc.enabled ? '启用' : '禁用'}`)
      return json(res, 200, { ok: true, id: acc.id, enabled: acc.enabled })
    }
    if (p === '/v1/models' || p === '/models') {
      const cache = await loadModels()
      return json(res, 200, { object: 'list', data: cache.data })
    }
    if (p === '/v1/chat/completions' || p === '/chat/completions') {
      if (req.method !== 'POST') return json(res, 405, { error: 'method not allowed' })
      return handleChat(req, res)
    }
    return json(res, 404, { error: 'not found' })
  } catch (err) {
    log(`请求处理异常 ${p}：${err?.stack || err}`)
    if (!res.headersSent) json(res, 500, { error: String(err?.message || err) })
    else res.end()
  }
})

// ---------------------------------------------------------------- 启动
discoverAccounts()
log(`已发现 ${accounts.size} 个账号：${[...accounts.values()].map((a) => `${a.id}(${a.source})`).join(', ') || '无'}`)
setInterval(discoverAccounts, CONFIG.discoveryIntervalMs).unref()
loadModels({ force: true }).catch(() => {})
refreshAllCredits().catch(() => {})
setInterval(() => refreshAllCredits().catch(() => {}), Math.min(30000, CONFIG.creditRefreshInterval)).unref()

server.listen(CONFIG.port, CONFIG.host, () => {
  log(`loomy-proxy v${VERSION} 监听 http://${CONFIG.host}:${CONFIG.port}`)
  log(`上游 ${CONFIG.upstream} · 模式 ${accounts.size >= 2 ? 'pool' : 'single'} · 管理面板 http://${CONFIG.host}:${CONFIG.port}/admin`)
})
